using System;
//using BMWTPDC.localhost;
using BMWTPDC.com.wsmq.www;
using NUnit.Framework;

namespace BMWTPDC
{
	/// <summary>
	/// Summary description for BMWTPDCServiceTest.
	/// </summary>
	[TestFixture]
	public class BMWTPDCServiceTest
	{
		[Test, ExpectedException(typeof(System.Web.Services.Protocols.SoapException))]
		public void TestIncompleteRequest()
		{
			PDCContestEntryService serv = new PDCContestEntryService();
			serv.CreateBlogPostEntry(new EntryServiceRequest());
		}
		
		[Test]
		public void TestRequest()
		{
			PDCContestEntryService serv = new PDCContestEntryService();
			EntryServiceRequest request = new EntryServiceRequest();
			request.BlogUrl = "http://codebetter.com/blogs/brendan.tompkins";
			request.FirstName = "Brendan";
			request.LastName = "Tompkins";
			request.Interests = ".NET and C#";

			EntryServiceResponse response = serv.CreateBlogPostEntry(request);
			Assert.IsNotNull(response, "Oops, null response");
			Assert.IsNotNull(response.PostBody, "Oops, null body section");
			
			Console.Out.WriteLine(response.PostBody);
		}
		
	}
}
