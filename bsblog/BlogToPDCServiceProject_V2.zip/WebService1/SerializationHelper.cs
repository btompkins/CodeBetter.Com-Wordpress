using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace BMWTPDC
{
	/// <summary>
	///     Class with utilities for the serialization of objects to and from XML
	/// </summary>
	/// <remarks>
	///     
	/// </remarks>
	public class SerializationHelper
	{
		/// <summary>
		/// Serialize an object using the Binary Formatter
		/// </summary>
		/// <param name="serializableObject">Object that can be serialized</param>
		/// <returns>byte[] representation of the object</returns>
		public byte[] BinarySerialize(object serializableObject)
		{
			BinaryFormatter bf = new BinaryFormatter();
			MemoryStream ms = new MemoryStream();

			bf.Serialize(ms,serializableObject);

			return ms.ToArray();
		}

		/// <summary>
		/// Restore (Deserialize) an object, given a binary formatted byte array
		/// </summary>
		/// <param name="binaryFormattedObject">A byte[] that represents a previously binary-formatted object</param>
		/// <returns>A un-typed restored object</returns>
		public object BinaryDeSerialize(byte[] binaryFormattedObject)
		{
			BinaryFormatter bf = new BinaryFormatter();
			MemoryStream ms = new MemoryStream(binaryFormattedObject);

			return bf.Deserialize(ms);
		}

		/// <summary>
		/// Serialize an object into XML
		/// </summary>
		/// <param name="serializableObject">Object that can be serialized</param>
		/// <returns>Serial XML representation</returns>
		public static string XmlSerialize(object serializableObject)
		{	
			XmlSerializer serializer = new XmlSerializer(serializableObject.GetType());
			System.IO.MemoryStream aMemStr = new System.IO.MemoryStream();
			System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(aMemStr, null);
			serializer.Serialize(writer,serializableObject);
			string strXml = System.Text.Encoding.UTF8.GetString(aMemStr.ToArray());
			return strXml;			
		}

		/// <summary>
		/// XMLs the serialize.
		/// </summary>
		/// <param name="serializableObject">Serializable object.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <returns></returns>
		public static void XmlSerialize(object serializableObject, string fileName)
		{	
			XmlSerializer serializer = new XmlSerializer(serializableObject.GetType());
			System.IO.MemoryStream aMemStr = new System.IO.MemoryStream();
			System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(aMemStr, null);
			serializer.Serialize(writer,serializableObject);
			string strXml = System.Text.Encoding.UTF8.GetString(aMemStr.ToArray());


			StreamWriter sw = null;
			try
			{
				sw = File.CreateText(fileName);	
				sw.Write(strXml);
			}
			finally
			{
				if(sw != null) sw.Close();				
			}
		}


		/// <summary>
		/// XMLs the de serialize.
		/// </summary>
		/// <param name="objectType">Object type.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <returns></returns>
		public static object XmlDeSerialize(Type objectType, string fileName)
		{
			XmlSerializer serializer = new XmlSerializer(objectType);
	
		
			StreamReader sr = null;
			string xmlString = String.Empty;
			try
			{
				sr = File.OpenText(fileName);	
				xmlString = sr.ReadToEnd();
			}
			finally
			{
				if(sr != null) sr.Close();				
			}

			System.IO.MemoryStream aStream = new
				System.IO.MemoryStream(System.Text.ASCIIEncoding.ASCII.GetBytes(xmlString));
			
			return serializer.Deserialize(aStream);
		}

		/// <summary>
		/// Restore (Deserialize) an object, given an XML string
		/// </summary>
		/// <param name="xmlString">XML</param>
		/// <param name="serializableObject">Object to restore as</param>
		public static object XmlDeSerialize(string xmlString, object serializableObject)
		{
			XmlSerializer serializer = new XmlSerializer(serializableObject.GetType());			
			System.IO.MemoryStream aStream = new
				System.IO.MemoryStream(System.Text.ASCIIEncoding.ASCII.GetBytes(xmlString));
			
			return serializer.Deserialize(aStream);
		}

		
		/// <summary>
		/// XMLs the de serialize.
		/// </summary>
		/// <param name="xmlString">Xml string.</param>
		/// <param name="objectType">Object type.</param>
		/// <returns></returns>
		public static object XmlDeSerialize(string xmlString, Type objectType)
		{
			XmlSerializer serializer = new XmlSerializer(objectType);			
			System.IO.MemoryStream aStream = new
				System.IO.MemoryStream(System.Text.ASCIIEncoding.ASCII.GetBytes(xmlString));
			
			return serializer.Deserialize(aStream);
		}
	}
}
