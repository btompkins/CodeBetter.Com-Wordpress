using System;
using System.Text;
using System.Web.Services.Protocols;
using BMWTPDC.com.amazon.webservices;
using BMWTPDC.com.wsmq.www;
using Google_Web_APIs_Demo.Google;
using Microsoft.Web.Services2.Security;
using Microsoft.Web.Services2.Security.Tokens;

namespace BMWTPDC
{
	/// <summary>
	/// Summary description for PdcContestService.
	/// </summary>
	public class PdcContestService
	{

		/// <summary>
		/// Generates the response.
		/// </summary>
		/// <param name="request">Request.</param>
		/// <returns></returns>
		public EntryServiceResponse GenerateResponse(EntryServiceRequest request)
		{
			// First Validate the request
			request.Validate();

			EntryServiceResponse response = new EntryServiceResponse();
			StringBuilder body = new StringBuilder();
			body.Append(GetProlouge(request));
			body.Append(GetGoogleLinks(request));
			body.Append(GetAmazonInterestes(request));
			body.Append(GetOtherEntryUrls(request));
			response.PostBody += body.ToString();

			return response;
		}
	
		/// <summary>
		/// Gets the prolouge.
		/// </summary>
		/// <param name="request">Request.</param>
		/// <returns></returns>
		public  string GetProlouge(EntryServiceRequest request)
		{
			return @"<h1>I&rsquo;m Blog&rsquo;n my way to the PDC!</h1>
				<p>If you haven&rsquo;t heard, <a href=""http://channel9.msdn.com/"">Channel9</a> 
				has started a contest where you can <a href=""http://channel9.msdn.com/ShowPost.aspx?PostID=74816"">
				win a ticket to the PDC</a>, including an airline ticket and hotel!&nbsp; This is one amazing contest, 
				and all you have to do to enter is&nbsp;have a blog, and&nbsp;post why <em>you</em> 
				should win the prize.&nbsp; So here&rsquo;s my official entry:</p><a 
				href=""http://channel9.msdn.com/pdc/pdcfriends.aspx?contest=true""><img 
				alt=""blogging my way to pdc"" src=""http://channel9.msdn.com/pdc/Flairs/Blogmyway-v.jpg"" /> </a>
				
				<h2>Here's some information to help you get to know me better:</h2>
			";
		
		}
		
		/// <summary>
		/// Gets the other entry urls.
		/// </summary>
		/// <param name="request">Request.</param>
		/// <returns></returns>
		public string GetOtherEntryUrls(EntryServiceRequest request)
		{
			StringBuilder sb = new StringBuilder(@"
					<h2>Did I type up all this ugly HTML for this Blog post myself?</h2>
					<p>Heck no!&nbsp; I&rsquo;m lazy!&nbsp; But that&rsquo;s exactly why I need to go to PDC!&nbsp; The PDC is all about the future, 
					and in the future, we&rsquo;ll all be using&nbsp;cool&nbsp;technology to do things like typing tedious, boring contest entries.&nbsp; I&rsquo;m getting a head start on&nbsp;the salad&nbsp;days, so&nbsp;I figured out how to use&nbsp;ASMX 
					<a href=""http://www.wsmq.com/PDCService/PDCContestEntryService.asmx"">web service</a> that 
					<a href=""http://codebetter.com/blogs/brendan.tompkins/"">Brendan</a> wrote! To prove it, you can see 
					that I'm on this list of other, lazy coders who&nbsp;would&nbsp;rather sit back and use a distributed Web Service to do their work!&nbsp;&nbsp; </p>
					" + Environment.NewLine);
			try
			{			
				MessageQueueServiceWse  mqs = CreateProxy("pdc", "pdcpdc", false);
				QueueRequest qr = new QueueRequest();
				qr.QueueName = "PDC";
		
				string entries = mqs.Receive(qr);
		
				EntryServiceRequestCollection allEntries = null;
				if(entries != null)
				{
					allEntries = SerializationHelper.XmlDeSerialize(entries, typeof(EntryServiceRequestCollection)) as EntryServiceRequestCollection;
				}
				else
				{
					allEntries = new EntryServiceRequestCollection();
				}
	
				if(!allEntries.Contains(request))
				{	
					allEntries.Add(request);
				}

				SendQueueRequest sqr = new SendQueueRequest();
				sqr.QueueName = "PDC";
				sqr.Message = SerializationHelper.XmlSerialize(allEntries);
				mqs.Send(sqr);

				sb.Append("<ul>");
				String format = "<li><a href=\"{2}\">{0} {1}</a></li>" + Environment.NewLine;

				foreach(EntryServiceRequest esr in allEntries)
				{
					if(esr.BlogUrl == request.BlogUrl)
					{
						sb.AppendFormat(format, "ME!!!", string.Empty, esr.BlogUrl);
					}
					else
					{
						sb.AppendFormat(format, esr.FirstName, esr.LastName, esr.BlogUrl);
					}
				}

				sb.Append("</ul></p>");

				return sb.ToString();

			}
			catch (SoapException) 
			{
				sb.Append("I guess WSMQ isn't working.  I should have queued this request somewhere..") ;
			}

			return sb.ToString();
		}

		/// <summary>
		/// Creates the WSMQ proxy.
		/// </summary>
		/// <param name="userName">Name of the user.</param>
		/// <param name="password">Password.</param>
		/// <param name="encryptRequest">Encrypt request.</param>
		/// <returns></returns>
		private MessageQueueServiceWse CreateProxy(string userName, string password, bool encryptRequest)
		{
			// create the proxy
			MessageQueueServiceWse proxy = new MessageQueueServiceWse();
			
			// Create the token
			UsernameToken token = new UsernameToken(userName, password, PasswordOption.SendNone);

			// Add the signature element to a security section on the request
			// to sign the request
			proxy.RequestSoapContext.Security.Tokens.Add( token );
			proxy.RequestSoapContext.Security.Elements.Add( new MessageSignature( token ) );

			// Set the TTL to one minute to prevent reply attacks
			proxy.RequestSoapContext.Security.Timestamp.TtlInSeconds = 60;

			// encrypt it
			if (encryptRequest == true)
				proxy.RequestSoapContext.Security.Elements.Add(new EncryptedData(token));
			
			return proxy;
		}

		/// <summary>
		/// Gets the amazon interestes.
		/// </summary>
		/// <param name="request">Request.</param>
		/// <returns></returns>
		public string GetAmazonInterestes(EntryServiceRequest request)
		{
			AWSECommerceService amazonService = new AWSECommerceService();

			StringBuilder sb = new StringBuilder(
				@"<h2>What are my interests?</h2>
				<p>&nbsp;Well, here&rsquo;s a list of books that I'll probably be reading on 
				the plane to LAX : </p>" + System.Environment.NewLine);

			try 
			{

				ItemSearch itemSearch = new ItemSearch();
				ItemSearchRequest itemSearchRequest = new ItemSearchRequest();
				ItemSearchResponse itemSearchResponse = new ItemSearchResponse();

				//build request to Amazon
				itemSearch.SubscriptionId = System.Configuration.ConfigurationSettings.AppSettings["AMAZON_KEY"];
				itemSearchRequest.Keywords = request.Interests;
				itemSearchRequest.SearchIndex = "Books";
				itemSearchRequest.ResponseGroup = new string [] { "Small", "Images", "ItemAttributes", "OfferFull" };
				itemSearch.Request = new ItemSearchRequest[1] {itemSearchRequest};

				//send the query
				itemSearchResponse = amazonService.ItemSearch(itemSearch);

				Items[] itemsResponse = itemSearchResponse.Items; 

				// Check for errors in the reponse
				if ( itemsResponse == null ) 
				{
					sb.Append("I'm not very interesting according to Amazon.");
				}
				if ( itemsResponse[0].Request.Errors != null )
				{
					sb.Append("I'm not very interesting according to Amazon.");
				}
				if ( itemsResponse != null ) 
				{ 
					//note that we only sent one request
					//so we only have one response, which is the first
				
					Items items = itemsResponse[0];
					if ( items != null ) 
					{ 
						
						String format = "<img src=\"{1}\"/> <a href=\"{2}\">{0}</a> " + Environment.NewLine;

						//display total results
						Item [] results = items.Item; 
						if ( results != null ) 
						{ 
							int maxBooks = 3;
							int totalBooks = 0;

							foreach ( Item item in results ) 
							{ 
								if(totalBooks++ == maxBooks) break;

								if ( item != null && item.ItemAttributes.Title != null && item.MediumImage != null && item.DetailPageURL != null) 
								{ 
									sb.AppendFormat(format, item.ItemAttributes.Title, item.SmallImage.URL, item.DetailPageURL);
								}
							} 
						} 

						sb.Append("</ul>" + Environment.NewLine);
					} 
				} 
			}
			catch (SoapException) 
			{
				sb.Append("I'm not very interesting according to Amazon.") ;
			}

			return sb.ToString();
		}

		/// <summary>
		/// Gets the google links.
		/// </summary>
		/// <param name="request">Request.</param>
		/// <returns></returns>
		public string GetGoogleLinks(EntryServiceRequest request)
		{
			GoogleSearchService s = new GoogleSearchService();
			StringBuilder sb = new StringBuilder(
				@"<h2>Why me?</h2>	
					<p>Why do I want to go to the PDC? Because I love to blog! And I'm prolific! 
					Here's some of my more popular blog posts links according to Google : </p>" + 
				Environment.NewLine);		

			try 
			{
				// Invoke the search method
				GoogleSearchResult r = 
					s.doGoogleSearch(System.Configuration.ConfigurationSettings.AppSettings["GOOGLE_KEY"], 
					request.BlogUrl, 
					0,
					5,
					false,
					"",
					false, 
					"",
					"",
					"");

	
				String format = "<li><a href=\"{1}\">{0}</a></li>" + Environment.NewLine;

				for(int i = 0; i < r.resultElements.Length; i++)
				{
					sb.AppendFormat(format, r.resultElements[i].title, r.resultElements[i].URL);
				}

				sb.Append("</ul>"+ Environment.NewLine);

			}
			catch (SoapException) 
			{
				sb.Append("Google doesn't even know me! Send me to PDC! I promise I'll blog!");
			}
			
			sb.Append("</p>");
			return sb.ToString();
		}
	}
}
