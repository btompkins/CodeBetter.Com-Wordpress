using System.ComponentModel;
using System.Web.Services;

namespace BMWTPDC
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	[WebService(Namespace="http://www.codebetter.com/webservices/")]
	public class PDCContestEntryService : WebService
	{
		public PDCContestEntryService()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion


		/// <summary>
		/// Creates the blog post entry.
		/// </summary>
		/// <param name="request">Request.</param>
		/// <returns></returns>
		[WebMethod]
		public EntryServiceResponse CreateBlogPostEntry(EntryServiceRequest request)
		{
			PdcContestService srv = new PdcContestService();
			return srv.GenerateResponse(request);
		}
	}
}
