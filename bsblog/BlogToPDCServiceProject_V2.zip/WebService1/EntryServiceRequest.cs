using System;

namespace BMWTPDC
{
	[Serializable]
	public class EntryServiceRequest
	{
		public EntryServiceRequest()
		{}

		public EntryServiceRequest(string firstName, string lastName,string interests, string blogUrl)
		{
			this.firstName = firstName;
			this.lastName = lastName;
			this.blogUrl = blogUrl;
			this.interests = interests;
		}

		string firstName = String.Empty;
		string lastName  = String.Empty;
		string blogUrl  = String.Empty;
		string interests = String.Empty;

		public string FirstName
		{
			get { return firstName; }
			set { firstName = value; }
		}

		public string LastName
		{
			get { return lastName; }
			set { lastName = value; }
		}

		public string BlogUrl
		{
			get { return blogUrl; }
			set { blogUrl = value; }
		}

		public string Interests
		{
			get { return interests; }
			set { interests = value; }
		}
		

		/// <summary>
		/// Validates the request.
		/// </summary>
		public void Validate()
		{
			if(	firstName.Length == 0 ||
				lastName.Length == 0 ||
				blogUrl.Length == 0 ||
				interests.Length == 0)

			{
				throw new ArgumentNullException("You must supply FirstName, LastName, BlogUrl and Interests.");
			}
		}
	}

}
