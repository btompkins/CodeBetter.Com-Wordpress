//------------------------------------------------------------------------------
// <copyright company="Telligent Systems">
//     Copyright (c) Telligent Systems Corporation.  All rights reserved.
// </copyright> 
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.ComponentModel;
using System.Web.UI.WebControls;
using CommunityServer.Blogs.Components;
using CommunityServer.Components;

namespace CommunityServer.Blogs.Controls
{
    /// <summary>
    /// Summary description for AggregateBlogList.
    /// </summary>
    public class AggregateCompactBlogList : WeblogBaseTemplatedWebControl
    {
    	Repeater GroupList = null;
        public AggregateCompactBlogList()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        protected override void AttachChildControls()
        {
            GroupList = FindControl( "GroupList" ) as Repeater;
            GroupList.ItemCreated +=new RepeaterItemEventHandler(Groups_ItemCreated);

            DataBind();
        }

        public override void DataBind()
        {
            base.DataBind ();

            int groupID =  Globals.SafeInt(Context.Request.QueryString["GroupID"],-1);
            

            if(groupID > 0)
            {

                Group g = WeblogGroups.GetWeblogGroup(groupID,this.CurrentUser,true,false);
                if(g != null)
                    GroupList.DataSource = new Group[]{g};
            }
            else
            {
                GroupList.DataSource = WeblogGroups.GetWeblogGroups(this.CurrentUser,true,false,false);
            }

            GroupList.DataBind();			
        }



        private void Groups_ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            switch ( e.Item.ItemType ) 
            {
                case ListItemType.Item:
                case ListItemType.AlternatingItem:
                case ListItemType.SelectedItem:

                    Group g = e.Item.DataItem as Group;
            		ArrayList blogs = Weblogs.GetWeblogsByGroupID(g.GroupID,this.CurrentUser,false,true,false);

					CollectionView sortedBlogs = new CollectionView(blogs); 
					sortedBlogs.ApplySort("PostCount", ListSortDirection.Descending);

                    Repeater BlogList = e.Item.FindControl( "BlogList" ) as Repeater;
                    BlogList.ItemCreated +=new RepeaterItemEventHandler(BlogList_ItemCreated);
                    BlogList.DataSource = sortedBlogs;
                    BlogList.DataBind();

                    HyperLink GroupName = e.Item.FindControl("GroupName") as HyperLink;
                    GroupName.NavigateUrl = BlogUrls.Instance().GroupList(g.GroupID);
                    GroupName.Text = g.Name;


                    break;
            }
        }

        private void BlogList_ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            switch ( e.Item.ItemType ) 
            {
                case ListItemType.Item:
                case ListItemType.AlternatingItem:
                case ListItemType.SelectedItem:

                    Weblog blog = e.Item.DataItem as Weblog;

                    HyperLink name = e.Item.FindControl("BlogName") as HyperLink;
                   // Literal desc = e.Item.FindControl("BlogDesc") as Literal;
                   // HyperLink recentPost = e.Item.FindControl("recentPost") as HyperLink;
                    Literal pc = e.Item.FindControl("PostCount") as Literal;
                    Literal cc = e.Item.FindControl("CommentCount") as Literal;
                    Literal tc = e.Item.FindControl("TrackbackCount") as Literal;

                    name.NavigateUrl = BlogUrls.Instance().HomePage(blog.ApplicationKey);
                    name.Text = blog.Name;

                   // desc.Text = blog.Description;
                   // recentPost.NavigateUrl = BlogUrls.Instance().ShortLink(blog.MostRecentPostID);
                   // recentPost.Text = blog.MostRecentPostSubject;

                    pc.Text = blog.PostCount.ToString();
                    cc.Text = blog.CommentCount.ToString();
                    tc.Text = blog.TrackbackCount.ToString();
                        
                    break;
            }
        }
    }
}
