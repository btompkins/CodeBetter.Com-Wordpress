using System;
using System.Data;
using System.Web.UI;

namespace DataSetFilters
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class Default : Page
	{
		protected Tompkins.Web.UI.WebControls.DataSetFilterControl DataSetFilterControl1;
		protected System.Web.UI.WebControls.Label lblFilter;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
	
		private void Page_Load(object sender, EventArgs e)
		{
			// Put user code to initialize the page here
			if(!IsPostBack)
				this.DataBind();
		}

		private DataSet GetData()
		{
		
			DataSet ds = new DataSet();
			DataTable dtAnimals = new DataTable("Animals");

			dtAnimals.Columns.Add("AnimalID", typeof(int));
			dtAnimals.Columns.Add("Animal", typeof(string));
			dtAnimals.Columns.Add("Name", typeof(string));
			dtAnimals.Columns.Add("Weight", typeof(float));
			dtAnimals.Columns.Add("Birth Date", typeof(DateTime));

			DataRow dr;

			// Add Animal Rows
			dr = dtAnimals.NewRow();
			dr[0] = 1000;
			dr[1] = "Dog";
			dr[2] = "Rex";
			dr[3] = 16.5;
			dr[4] = DateTime.Now.AddDays(3);
			dtAnimals.Rows.Add(dr);

			dr = dtAnimals.NewRow();
			dr[0] = 1001;
			dr[1] = "Cat";
			dr[2] = "Fluffy";
			dr[3] = 8;
			dr[4] = DateTime.Now.AddDays(47);
			dtAnimals.Rows.Add(dr);

			dr = dtAnimals.NewRow();
			dr[0] = 1002;
			dr[1] = "Hamster";
			dr[2] = "Benjy";
			dr[3] = 9.5;
			dr[4] = DateTime.Now.AddDays(-47);
			dtAnimals.Rows.Add(dr);

			dr = dtAnimals.NewRow();
			dr[0] = 1003;
			dr[1] = "Giraffe";
			dr[2] = "Cletus";
			dr[3] = 350.5;
			dr[4] = DateTime.Now.AddDays(-7);
			dtAnimals.Rows.Add(dr);

			dr = dtAnimals.NewRow();
			dr[0] = 1004;
			dr[1] = "Meerkat";
			dr[2] = "Squeaky";
			dr[3] = 2.5;
			dr[4] = DateTime.Now.AddDays(-71);
			dtAnimals.Rows.Add(dr);

			dr = dtAnimals.NewRow();
			dr[0] = 1005;
			dr[1] = "Orangutan";
			dr[2] = "Lihas";
			dr[3] = 231.5;
			dr[4] = DateTime.Now.AddDays(-100);
			dtAnimals.Rows.Add(dr);

			ds.Tables.Add(dtAnimals);
			return ds;
		}

		public override void DataBind()
		{
			DataSet ds = GetData();
			this.DataSetFilterControl1.DataSource = ds;
			this.DataSetFilterControl1.DataMember = ds.Tables[0].TableName;
			
			DataView dv = new DataView(ds.Tables[0]);
			dv.RowFilter = DataSetFilterControl1.RowFilter;
			lblFilter.Text = DataSetFilterControl1.RowFilter;

			this.DataGrid1.DataSource = dv;
			base.DataBind ();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();

			this.DataSetFilterControl1.FilterChanged+=new EventHandler(DataSetFilterControl1_FilterChanged);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataSetFilterControl1.FilterChanged += new System.EventHandler(this.DataSetFilterControl1_FilterChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void DataSetFilterControl1_FilterChanged(object sender, EventArgs e)
		{
			this.DataBind();
		}
	}
}
