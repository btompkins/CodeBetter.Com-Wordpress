using System;
using System.Data;

namespace Tompkins.Examples
{
	/// <summary>
	/// Summary description for DummyData.
	/// </summary>
	public class MockData
	{
		public static DataSet DummyDataSet
		{
			get
			{
				
				DataSet ds = new DataSet();
				DataTable dtAnimals = new DataTable("Animals");

				dtAnimals.Columns.Add("AnimalID", typeof(int));
				dtAnimals.Columns.Add("Animal", typeof(string));
				dtAnimals.Columns.Add("Name", typeof(string));
				dtAnimals.Columns.Add("Weight", typeof(float));
				dtAnimals.Columns.Add("Birth Date", typeof(DateTime));

				DataRow dr;

				// Add Animal Rows
				dr = dtAnimals.NewRow();
				dr[0] = 1000;
				dr[1] = "Dog";
				dr[2] = "Rex";
				dr[3] = 16.5;
				dr[4] = DateTime.Now.AddDays(3);
				dtAnimals.Rows.Add(dr);

				dr = dtAnimals.NewRow();
				dr[0] = 1001;
				dr[1] = "Cat";
				dr[2] = "Fluffy";
				dr[3] = 8;
				dr[4] = DateTime.Now.AddDays(47);
				dtAnimals.Rows.Add(dr);

				dr = dtAnimals.NewRow();
				dr[0] = 1002;
				dr[1] = "Hamster";
				dr[2] = "Benjy";
				dr[3] = 9.5;
				dr[4] = DateTime.Now.AddDays(-47);
				dtAnimals.Rows.Add(dr);

				dr = dtAnimals.NewRow();
				dr[0] = 1003;
				dr[1] = "Giraffe";
				dr[2] = "Cletus";
				dr[3] = 350.5;
				dr[4] = DateTime.Now.AddDays(-7);
				dtAnimals.Rows.Add(dr);

				dr = dtAnimals.NewRow();
				dr[0] = 1004;
				dr[1] = "Meerkat";
				dr[2] = "Squeaky";
				dr[3] = 2.5;
				dr[4] = DateTime.Now.AddDays(-71);
				dtAnimals.Rows.Add(dr);

				dr = dtAnimals.NewRow();
				dr[0] = 1005;
				dr[1] = "Orangutan";
				dr[2] = "Lihas";
				dr[3] = 231.5;
				dr[4] = DateTime.Now.AddDays(-100);
				dtAnimals.Rows.Add(dr);

				ds.Tables.Add(dtAnimals);

				return ds;
			}
		}
	}
}
