using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tompkins.Web.UI.WebControls;

namespace Tompkins.Examples
{
	public class DataSetFilters : UserControl
	{
		protected DataSetFilterControl DataSetFilterControl1;
		protected Label lblFilter;
		protected DataGrid DataGrid1;
	
		private void Page_Load(object sender, EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
				this.DataBind();
		}

		

		public override void DataBind()
		{
		
			this.DataSetFilterControl1.DataSource = MockData.DummyDataSet;
			this.DataSetFilterControl1.DataMember = MockData.DummyDataSet.Tables[0].TableName;
			
			DataView dv = new DataView(MockData.DummyDataSet.Tables[0]);
			dv.RowFilter = DataSetFilterControl1.RowFilter;
			lblFilter.Text = DataSetFilterControl1.RowFilter;

			this.DataGrid1.DataSource = dv;
			base.DataBind ();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();

			this.DataSetFilterControl1.FilterChanged+=new EventHandler(DataSetFilterControl1_FilterChanged);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DataSetFilterControl1.FilterChanged += new EventHandler(this.DataSetFilterControl1_FilterChanged);
			this.Load += new EventHandler(this.Page_Load);

		}
		#endregion

		private void DataSetFilterControl1_FilterChanged(object sender, EventArgs e)
		{
			this.DataBind();
		}
	}
}
