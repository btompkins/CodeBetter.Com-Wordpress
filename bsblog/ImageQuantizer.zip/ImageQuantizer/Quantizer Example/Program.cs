using System.Drawing;
using System.Drawing.Imaging;
using ImageQuantization;

namespace _bitTest
{
    class Program
    {
        static void Main(string[] args)
        {
           

            Image img = Image.FromFile("original_image.gif");
            OctreeQuantizer quantizer = new OctreeQuantizer(15, 4);
            using ( Bitmap quantized = quantizer.Quantize ( img ) )
            {
                quantized.Save("new_image_4bit.gif", ImageFormat.Gif);
            }

            quantizer = new OctreeQuantizer(255, 4);
            using (Bitmap quantized = quantizer.Quantize(img))
            {
                quantized.Save("new_image_8bit.gif", ImageFormat.Gif);
            }

            GrayscaleQuantizer gquantizer = new GrayscaleQuantizer();
            using (Bitmap quantized = gquantizer.Quantize(img))
            {
                quantized.Save("new_image_grayscale.gif", ImageFormat.Gif);
            }

        }
    }
}