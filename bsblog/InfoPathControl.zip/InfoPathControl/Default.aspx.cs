using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace InfoPathControl
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected InfoPathWebControl InfoPathWebControl1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			this.DataBind();
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.InfoPathWebControl1.FormSubmitted += new InfoPathControl.InfoPathWebControl.InfoPathFormEventHandler(this.InfoPathWebControl1_FormSubmitted);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InfoPathWebControl1_FormSubmitted(object sender, InfoPathControl.InfoPathWebControl.InfoPathFormEventArgs e)
		{
			System.Web.UI.WebControls.DataGrid dg = new DataGrid();
			dg.AutoGenerateColumns = true;
			dg.DataSource = e.FormDataSet;
			dg.DataBind();
			this.Controls.Add(dg);
			this.InfoPathWebControl1.Visible = false;
		}
	}
}
