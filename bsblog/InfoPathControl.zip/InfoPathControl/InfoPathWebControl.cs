using System;
using System.Xml;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Collections;

namespace InfoPathControl
{
	/// <summary>
	/// Web Viewer for InfoPath forms...
	/// </summary>
	[DefaultEvent("FormSubmitted")]
	public class InfoPathWebControl : System.Web.UI.WebControls.WebControl
	{
		protected System.Web.UI.WebControls.Button btnSubmit;
		private Hashtable formFieldHash;
	
		public event InfoPathWebControl.InfoPathFormEventHandler FormSubmitted;

		protected override void OnInit(EventArgs e)
		{
			this.xmlDirectory = this.Page.Server.MapPath(".") + "\\";
			base.OnInit (e);
		}

		public override void DataBind()
		{
			System.IO.StreamReader strmRdr = System.IO.File.OpenText(this.xmlDirectory + this.xmlTemplate);
			string xmlText = strmRdr.ReadToEnd();
			strmRdr.Close();

			string strXHTML =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + Util.XSLTransformationHelper.TransformToString(xmlText, this.xmlDirectory + this.xslTemplate);
			
			XmlDocument myXmlDocument = new XmlDocument();
			myXmlDocument.LoadXml(strXHTML);

			string strStyle = null;

			XmlNodeList styleList = myXmlDocument.SelectNodes("html/head/style");
			foreach(XmlNode node in styleList)
			{
				if(node.Attributes["controlStyle"] == null)
					strStyle += node.InnerXml;
			}


			XmlNode bodyNode = myXmlDocument.SelectSingleNode("html/body");
			string strBodyHTML = bodyNode.InnerXml;

			string styleSheetFmt = @"<style>
	{0}
</style>";
			this.Controls.Add(new System.Web.UI.LiteralControl(String.Format(styleSheetFmt, strStyle)));

			formFieldHash = new Hashtable();

			strBodyHTML =  Regex.Replace(strBodyHTML, ReplaceTextBoxRegEx, new MatchEvaluator(this.ReplaceTextBox));
			strBodyHTML =  Regex.Replace(strBodyHTML, ReplaceSelectListRegEx, new MatchEvaluator(this.ReplaceSelectList));
			strBodyHTML =  Regex.Replace(strBodyHTML, ReplaceRadioButtonRegEx, new MatchEvaluator(this.ReplaceRadioButton));

			this.Controls.Add(new System.Web.UI.LiteralControl(strBodyHTML));

			btnSubmit = new Button();
			btnSubmit.Text	= "Submit";
			btnSubmit.ID	= "btnSubmit";
			btnSubmit.Click +=new EventHandler(btnSubmit_Click);

			this.Controls.Add(btnSubmit);
		}

		#region Radio Button
		private static string ReplaceRadioButtonRegEx
		{
			get
			{
				return @"<input class=""xdBehavior_Boolean"".*?xd:binding="".*?:(?<id>[^""^/]*).*? xd:onValue=""(?<value>[^""]*).*?>";
			}
		}

		private string ReplaceRadioButton(Match m) 
		{
			//<input class="xdBehavior_Boolean" 
			//	title="" 
			//  type="radio" 
			//  name="XSLTmy:Feature130122120" 
			//  tabIndex="0" 
			//  xd:CtrlId="CTRL11" 
			//  xd:xctname="OptionButton" 
			//  xd:binding="my:Feature" 
			//  xd:boundProp="xd:value" 
			//  xd:onValue="Watch List" 
			//  xd:value="" 
			//  xmlns:xd="http://schemas.microsoft.com/office/infopath/2003">
			//</input>

			string strID	= m.Groups["id"].Value;
			string strValue = m.Groups["value"].Value;
			string strFormatString = @"<input type=""radio"" name=""{0}"" value=""{1}"">";
			string x = String.Format(strFormatString, strID, strValue);

			if(!this.formFieldHash.ContainsKey(strID)) this.formFieldHash.Add(strID, null);

			return x;
		
		}
		#endregion

		#region Select List
		private static string ReplaceSelectListRegEx
		{
			get
			{
				return @"<select class=""xdComboBox xdBehavior_Select"".*?xd:binding="".*?:(?<id>[^""^/]*).*?style=""(?<style>[^""]*)"".*?>";
			}
		}

		private string ReplaceSelectList(Match m) 
		{
			// <select class="xdComboBox xdBehavior_Select" title="" size="1" tabIndex="0" xd:CtrlId="CTRL3" xd:xctname="DropDown" xd:binding="my:useFrequency" xd:boundProp="value" style="WIDTH: 130px" value="" xmlns:xd="http://schemas.microsoft.com/office/infopath/2003">
			//   <option selected="selected">Select...</option>
			//   <option value="Daily">Daily</option>
			//   <option value="Weekly">Weekly</option>
			//   <option value="Monthly">Monthly</option>
			//   <option value="Never">Never</option>
			// </select>

			string strID	= m.Groups["id"].Value;
			string strStyle = m.Groups["style"].Value;
			string strFormatString = @"<select name=""{0}"" style=""{1}"">";
			string x = String.Format(strFormatString, strID, strStyle);

			if(!this.formFieldHash.ContainsKey(strID)) this.formFieldHash.Add(strID, null);
			return x;
		
		}
		#endregion

		#region TextBox
		private static string ReplaceTextBoxRegEx
		{
			get
			{
				return @"<span class=""xdTextBox"".*?xd:binding="".*?:(?<id>[^""^/]*).*?style=""(?<style>[^""]*).*?>(?<value>.*?)</span>";
			}
		}

		private string ReplaceTextBox(Match m) 
		{
			// <span 
			//	class		= "xdTextBox" 
			//  hideFocus	= "1" 
			//  title		= "" 
			//  xd:binding	= "my:jobFunction" 
			//  tabIndex	= "0" 
			//  xd:xctname	= "PlainText" 
			//  xd:CtrlId	= "CTRL1" 
			//  style		= "WIDTH: 130px" 
			//  xmlns:xd	= "http://schemas.microsoft.com/office/infopath/2003">
			// </span>

			string strID	= m.Groups["id"].Value;
			string strStyle = m.Groups["style"].Value;
			string strValue = m.Groups["value"].Value;
			string strFormatString = (m.ToString().IndexOf("WORD-WRAP") > 0)? 
				@"<textarea name=""{0}"" style=""{1}"">{2}</textarea>" :
				@"<input type=""text"" name=""{0}"" style=""{1}"" value=""{2}"">";
			string x = String.Format(strFormatString, strID, strStyle, strValue);
			if(!this.formFieldHash.ContainsKey(strID)) this.formFieldHash.Add(strID, null);

			return x;
		}
		#endregion

		private void btnSubmit_Click(object sender, EventArgs e)
		{
			DataSet ds = this.GetDataSet();
			DataRow dr = ds.Tables[0].Rows.Add(new object[]{});

			dr["Submit User"] =	this.Page.User.Identity.Name;			
			dr["Submit Date"] = System.DateTime.Now;

			foreach(string key in formFieldHash.Keys)
			{
				 dr[key] = this.Page.Request[key];
			}

			if(this.FormSubmitted != null)
				this.FormSubmitted(this,new InfoPathFormEventArgs(ds));
		}

		
		private DataSet GetDataSet()
		{
			DataSet ds = new DataSet(this.uniqueFormKey);
			DataTable table = ds.Tables.Add(this.uniqueFormKey + "_Results");

			table.Columns.Add("Submit User");
			table.Columns.Add("Submit Date");

			foreach(string key in formFieldHash.Keys)
			{
				table.Columns.Add(key);
			}

			return ds;
		}

		private string xmlDirectory;
		public string XmlDirectory
		{
			get
			{
				return xmlDirectory;
			}
			set
			{
				if (xmlDirectory == value)
					return;
				xmlDirectory = value;
			}
		}
		private string xmlTemplate;
		private string xslTemplate;
		private string uniqueFormKey;
		public string UniqueFormKey
		{
			get
			{
				return uniqueFormKey;
			}
			set
			{
				if (uniqueFormKey == value)
					return;
				uniqueFormKey = value;
			}
		}

		public string XmlTemplate
		{
			get
			{
				return xmlTemplate;
			}
			set
			{
				if (xmlTemplate == value)
					return;
				xmlTemplate = value;
			}
		}

		public string XslTemplate
		{
			get
			{
				return xslTemplate;
			}
			set
			{
				if (xslTemplate == value)
					return;
				xslTemplate = value;
			}
		}

		public delegate void InfoPathFormEventHandler(object sender, InfoPathFormEventArgs e);
		public class InfoPathFormEventArgs : EventArgs
		{
			public InfoPathFormEventArgs(DataSet ds)
			{
				this.formDataSet = ds;
			}
			private DataSet formDataSet;
			public DataSet FormDataSet
			{
				get
				{
					return formDataSet;
				}
			}
		}
	}
}
