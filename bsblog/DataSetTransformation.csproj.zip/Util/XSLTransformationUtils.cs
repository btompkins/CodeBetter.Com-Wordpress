using System.IO;
using System.Data;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace DataSetTransformation.Util
{

	/// <summary>
	///     Helper class containing static methods for transforming XML with XSLT...
	/// </summary>
	/// <remarks>
	///     Used primarily to transform the message body of a notification message.
	/// </remarks>
	public class XSLTransformationUtils
	{


		/// <summary>
		///    Transforms XML using XSLT
		/// </summary>
		/// <param name="xmlData" type="string">
		///     <para>
		///         XML Data to transform
		///     </para>
		/// </param>
		/// <param name="xslFilePath" type="string">
		///     <para>
		///         File path to the XSL file
		///     </para>
		/// </param>
		/// <returns>
		///     Returns the result of an XSL Transformation
		/// </returns>
		public static string TransformToString(string xmlData, string xslFilePath)
		{
			return TransformToString(xmlData, xslFilePath, true);
		}

		/// <summary>
		///     Transforms XML using XSLT, but omits the resulting XML Declaration..
		/// </summary>
		/// <param name="xmlData" type="string">
		///     <para>
		///         The XML data to transform
		///     </para>
		/// </param>
		/// <param name="xslFilePath" type="string">
		///     <para>
		///         File path to the XSL File
		///     </para>
		/// </param>
		/// <param name="OmitXMLDeclartion" type="bool">
		///     <para>
		///         
		///     </para>
		/// </param>
		/// <returns>
		///     A string value...
		/// </returns>
		public static string TransformToString(string xmlData, string xslFilePath, bool OmitXMLDeclartion)
		{
			//Create a new XslTransform object.
			XslTransform xslt = new XslTransform();

			//Load the stylesheet.
			xslt.Load(xslFilePath);

			// Read the string into the xmltext reader
			XmlTextReader xr = new XmlTextReader(new StringReader(xmlData));

			//Create a new XPathDocument and load the XML data to be transformed.
			XPathDocument mydata = new XPathDocument(xr);

			System.IO.MemoryStream aMemStr = new System.IO.MemoryStream();

			//Create an XmlTextWriter which outputs to the console.
			XmlWriter writer = new XmlTextWriter(aMemStr, null);

			//Transform the data and send the output to the console.
			xslt.Transform(mydata, null, writer, null);

			writer.Close();

			string strXml = System.Text.Encoding.UTF8.GetString(aMemStr.ToArray());

			// Have to do this, because when outuptting to a stream, the XslTransform ignores the 
			// omit declaration in the XSL file.
			return (OmitXMLDeclartion) ? strXml : 	"<?xml version=\"1.0\" encoding=\"utf-8\"?>" + strXml;
		}
		

		public static MemoryStream TransformToMemoryStream(string xmlData, string xslFilePath)
		{
			//Create a new XslTransform object.
			XslTransform xslt = new XslTransform();

			//Load the stylesheet.
			xslt.Load(xslFilePath);

			// Read the string into the xmltext reader
			XmlTextReader xr = new XmlTextReader(new StringReader(xmlData));

			//Create a new XPathDocument and load the XML data to be transformed.
			XPathDocument mydata = new XPathDocument(xr);

			System.IO.MemoryStream aMemStr = new System.IO.MemoryStream();

			//Transform the data and send the output to the console.
			xslt.Transform(mydata, null, aMemStr, null);

			return aMemStr;
		}
		
		public static System.IO.MemoryStream TransformDataSet(DataSet ds, string xstFilePath)
		{
			MemoryStream instream = new MemoryStream();
			MemoryStream outstream = new MemoryStream();
			ds.WriteXml(instream, XmlWriteMode.IgnoreSchema);

			instream.Position = 0;
			//
			//		'load the xsl document
			XslTransform xslt = new XslTransform();
            xslt.Load(xstFilePath);

			//		'create the xmltextreader using the memory stream
			XmlTextReader xmltr = new XmlTextReader(instream);

			//		'create the xpathdoc

			XPathDocument xpathdoc = new XPathDocument(xmltr);
		
			//		'create XpathNavigator
			XPathNavigator nav = xpathdoc.CreateNavigator();

			//		'Create the XsltArgumentList.
			XsltArgumentList xslArg  = new XsltArgumentList();
	
			//		'Create a parameter that represents the current date and time.
			//string tablename;
			xslArg.AddParam("tablename", "", ds.Tables[0].TableName);
			
			//		'transform the xml to a memory stream
			xslt.Transform(nav, xslArg, outstream, null);		
			return outstream;
		}

		/// <summary>
		///     Transform XML using XSLT, and save the results to a file...
		/// </summary>
		/// <param name="xmlData" type="string">
		///     <para>
		///         The XML Data to transform
		///     </para>
		/// </param>
		/// <param name="xslFilePath" type="string">
		///     <para>
		///         The file path to the XSL
		///     </para>
		/// </param>
		/// <param name="resultFileName" type="string">
		///     <para>
		///         The File name to save to
		///     </para>
		/// </param>
		/// <returns>
		///     A void value...
		/// </returns>
		public static void TransformToFile(string xmlData, string xslFilePath, string resultFileName)
		{
			//Create a new XslTransform object.
			XslTransform xslt = new XslTransform();

			//Load the stylesheet.
			xslt.Load(xslFilePath);

			// Read the string into the xmltext reader
			XmlTextReader xr = new XmlTextReader(new StringReader(xmlData));

			//Create a new XPathDocument and load the XML data to be transformed.
			XPathDocument mydata = new XPathDocument(xr);

			//Create an XmlTextWriter which outputs to the console.
			XmlWriter writer = new XmlTextWriter(resultFileName, System.Text.Encoding.UTF8);

			//Transform the data and send the output to the console.
			xslt.Transform(mydata, null, writer, null);

			writer.Close();
		}
	}
}
