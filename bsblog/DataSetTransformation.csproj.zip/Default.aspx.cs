using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DataSetTransformation
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class Default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Panel pnlPivotTable;
		protected System.Web.UI.WebControls.Panel pnlPivotChart;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.Button btnExportXML;
		protected System.Web.UI.WebControls.Button btnExportTab;
		protected System.Web.UI.WebControls.Button btnExportComma;
		protected System.Web.UI.WebControls.Button btnExportExcelXML;
		protected System.Web.UI.WebControls.Button btnADOXML;
		protected System.Web.UI.WebControls.Button btnViewPivotTable;
		protected System.Web.UI.WebControls.Button btnViewPivotChart;
		protected DataSetTransformation.Common.ExampleDataSet exampleDataSet1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(this.Request.QueryString["ADOXML"] != null)
			{
				this.FillData();
				Util.ExportUtils.ExportDataSet(this.exampleDataSet1, "ADOXMLExport", Common.DataSetExportType.ADORecordSet, this.Context);
			}
			else if(!this.IsPostBack)
			{
				// Put user code to initialize the page here
				this.FillData();
				this.DataBind();
			}
		}

		public string XMLUrl
		{
			get
			{
				return this.Request.Path + "?ADOXML=TRUE";
			}
		}

		private void FillData()
		{
			System.Random randomValue = new System.Random();
			int intUniqueID = 0;

			for (int i = 0; i < 5; i++)
			{
				for(int j = 0; j < 10; j ++)
				{
					intUniqueID++;
					
					
					this.exampleDataSet1.ExampleDataTable.AddExampleDataTableRow(intUniqueID, "Column " + intUniqueID.ToString(), System.DateTime.Today.AddDays(intUniqueID), "Category " + (i+1).ToString(), randomValue.Next(100));
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.exampleDataSet1 = new DataSetTransformation.Common.ExampleDataSet();
			((System.ComponentModel.ISupportInitialize)(this.exampleDataSet1)).BeginInit();
			// 
			// exampleDataSet1
			// 
			this.exampleDataSet1.DataSetName = "ExampleDataSet";
			this.exampleDataSet1.Locale = new System.Globalization.CultureInfo("en-US");
			this.btnViewPivotTable.Click += new System.EventHandler(this.btnViewPivotTable_Click);
			this.btnViewPivotChart.Click += new System.EventHandler(this.btnViewPivotChart_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.exampleDataSet1)).EndInit();

		}
		#endregion

		private void DataGrid1_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			this.DataGrid1.CurrentPageIndex = e.NewPageIndex;
			this.FillData();
			this.DataBind();
		}

		private void btnExportXML_Click(object sender, System.EventArgs e)
		{
			this.FillData();
			Util.ExportUtils.ExportDataSet(this.exampleDataSet1, "XMLExport", Common.DataSetExportType.XML, this.Context);	
		}

		private void btnExportTab_Click(object sender, System.EventArgs e)
		{
			this.FillData();
			Util.ExportUtils.ExportDataSet(this.exampleDataSet1, "TABExport", Common.DataSetExportType.TabDelimited, this.Context);	
		}

		private void btnExportComma_Click(object sender, System.EventArgs e)
		{
			this.FillData();
			Util.ExportUtils.ExportDataSet(this.exampleDataSet1, "XMLComma", Common.DataSetExportType.CommaDelimited, this.Context);	
		
		}

		private void btnExportExcelXML_Click(object sender, System.EventArgs e)
		{
			this.FillData();
			Util.ExportUtils.ExportDataSet(this.exampleDataSet1, "ExcelXMLExport", Common.DataSetExportType.ExcelXML, this.Context);	
		
		}

		private void btnADOXML_Click(object sender, System.EventArgs e)
		{
			this.FillData();
			Util.ExportUtils.ExportDataSet(this.exampleDataSet1, "ADOXMLExport", Common.DataSetExportType.ADORecordSet, this.Context);	
		}

		private void btnViewPivotTable_Click(object sender, System.EventArgs e)
		{
			this.pnlPivotChart.Visible = false;
			this.pnlPivotTable.Visible = true;
		}

		private void btnViewPivotChart_Click(object sender, System.EventArgs e)
		{
			this.pnlPivotTable.Visible = false;
			this.pnlPivotChart.Visible = true;
		}
	}
}
