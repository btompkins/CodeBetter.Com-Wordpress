using System;

namespace DataSetTransformation.Common
{
	/// <summary>
	///     Type for exporting datasets..
	/// </summary>
	/// <remarks>
	///     This is used by the DataSetExporter 
	/// </remarks>
	public enum DataSetExportType
	{
		XML, 
		ExcelXML,
		TabDelimited,
		CommaDelimited,
		ADORecordSet
	}
}
