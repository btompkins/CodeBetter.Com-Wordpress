using System;

namespace DataSetTransformation.Common
{
	/// <summary>
	/// Summary description for Configuration.
	/// </summary>
	public class Configuration
	{
		public struct PathSettings
		{
			public static string XSLTPath = System.Configuration.ConfigurationSettings.AppSettings["XSLT_DIRECTORY"];
		}
	}
}
