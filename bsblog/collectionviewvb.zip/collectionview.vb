Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Reflection


<ToolboxItem(True), DesignTimeVisible(True), Serializable()> _
Public Class CollectionView

    Implements IBindingList

    Implements IComponent

    Implements IDisposable


    Public Event ListChanged As System.ComponentModel.ListChangedEventHandler Implements System.ComponentModel.IBindingList.ListChanged

    Public Sub New(ByVal list As IList)
        _baseList = list
        If TypeOf _baseList Is IBindingList Then
            supportsBinding = True
            bindingList = CType(_baseList, IBindingList)
            AddHandler bindingList.ListChanged, AddressOf SourceChanged
        End If
    End Sub

    Public Function Add(ByVal value As Object) As Integer Implements System.Collections.IList.Add
        Return _baseList.Add(value)
    End Function

    Public Sub AddIndex(ByVal _property As System.ComponentModel.PropertyDescriptor) Implements System.ComponentModel.IBindingList.AddIndex
        If supportsBinding Then
            bindingList.AddIndex(_property)
        End If
    End Sub

    Public Function AddNew() As Object Implements System.ComponentModel.IBindingList.AddNew
        If supportsBinding Then
            Return bindingList.AddNew
        End If
        Return Nothing
    End Function

    Public Sub ApplyFilter(ByVal a_property As String, ByVal compareValue As Object)
        Me.ApplyFilter(a_property, compareValue, FilterOperand.Equals)
    End Sub

    Public Enum FilterOperand
        Equals
        NotEquals
        Includes
        NotIncludes
    End Enum

    Public Sub ApplyFilter(ByVal a_property As String, ByVal compareValue As Object, ByVal operand As FilterOperand)
        Dim filterBy As PropertyDescriptor = GetPropertyDescriptor(a_property)
        If Not (filterBy Is Nothing) Then
            filteredList = New ArrayList
            For Each obj As Object In _baseList
                Dim f As Object = GetValue(obj, filterBy, a_property)
                Select Case operand
                    Case FilterOperand.Equals
                        If f.Equals(compareValue) Then
                            filteredList.Add(obj)
                        End If
                        ' break
                    Case FilterOperand.NotEquals
                        If Not (f.Equals(compareValue)) Then
                            filteredList.Add(obj)
                        End If
                        ' break
                    Case FilterOperand.Includes
                        Try
                            Dim s1 As String = f.ToString
                            Dim s2 As String = compareValue.ToString
                            If Not (s1.LastIndexOf(s2) = -1) Then
                                filteredList.Add(obj)
                            End If
                        Catch
                        End Try
                        ' break
                    Case FilterOperand.NotIncludes
                        Try
                            Dim s1 As String = f.ToString
                            Dim s2 As String = compareValue.ToString
                            If s1.LastIndexOf(s2) = -1 Then
                                filteredList.Add(obj)
                            End If
                        Catch
                        End Try
                        ' break
                End Select
            Next
            isFiltered = True
            If IsSorted Then
                DoSort()
            End If
            RaiseEvent ListChanged(Me, New ListChangedEventArgs(ListChangedType.Reset, 0))
        End If
    End Sub

    Public Sub ApplySort(ByVal a_property As String, ByVal direction As System.ComponentModel.ListSortDirection)
        sortBy = GetPropertyDescriptor(a_property)
        fullPropertyName = a_property
        ApplySort(sortBy, direction)
    End Sub

    Public Sub ApplySort(ByVal a_property As System.ComponentModel.PropertyDescriptor, ByVal direction As System.ComponentModel.ListSortDirection) Implements System.ComponentModel.IBindingList.ApplySort
        sortBy = a_property
        _sortDirection = direction
        DoSort()
    End Sub

    Public Sub Clear() Implements System.ComponentModel.IBindingList.clear
        _baseList.Clear()
        PropertyHash = New Hashtable
    End Sub

    Public Function Contains(ByVal value As Object) As Boolean Implements System.ComponentModel.IBindingList.Contains
        Return _baseList.Contains(value)
    End Function

    Public Sub CopyTo(ByVal array As System.Array, ByVal index As Integer) Implements System.Collections.ICollection.CopyTo
        BaseList.CopyTo(array, index)
    End Sub

    Public Function Find(ByVal a_property As System.ComponentModel.PropertyDescriptor, ByVal key As Object) As Integer Implements System.ComponentModel.IBindingList.Find
        If supportsBinding Then
            Return bindingList.Find(a_property, key)
        Else
            Return -1
        End If
    End Function

    Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
        If IsSorted Then
            Return New SortedEnumerator(sortedList, SortDirection)
        Else
            Return BaseList.GetEnumerator
        End If
    End Function

    Public Function IndexOf(ByVal value As Object) As Integer Implements System.Collections.IList.IndexOf
        If IsSorted Then
            Dim index As Integer = 0
            For Each item As ListItem In sortedList
                If item.Item.Equals(value) Then
                    Return index
                End If
                index += 1
            Next
            Return -1
        Else
            Return BaseList.IndexOf(value)
        End If
    End Function

    Public Sub Insert(ByVal index As Integer, ByVal value As Object) Implements System.Collections.IList.insert
        BaseList.Insert(index, value)
    End Sub

    Public Sub Remove(ByVal value As Object) Implements System.Collections.IList.Remove
        BaseList.Remove(value)
    End Sub

    Public Sub RemoveAt(ByVal index As Integer) Implements System.Collections.IList.Removeat
        Dim pos As Integer = index
        If IsSorted Then
            Dim o As Object = GetSortedItem(pos)
            pos = BaseList.IndexOf(o)
            If pos >= 0 Then
                BaseList.Remove(o)
                If isFiltered Then
                    filteredList.RemoveAt(pos)
                End If
                pos = Microsoft.VisualBasic.IIf((Me.SortDirection = ListSortDirection.Ascending), index, sortedList.Count - index - 1)
                sortedList.RemoveAt(pos)
            End If
        Else
            Dim o As Object = BaseList(pos)
            BaseList.Remove(o)
            If isFiltered Then
                BaseList.RemoveAt(pos)
            End If
        End If
        RaiseEvent ListChanged(Me, New ListChangedEventArgs(ListChangedType.ItemDeleted, pos))
    End Sub

    Public Sub RemoveFilter()
        If isFiltered Then
            filteredList = Nothing
            isFiltered = False
            If IsSorted Then
                DoSort()
            End If
            RaiseEvent ListChanged(Me, New ListChangedEventArgs(ListChangedType.Reset, 0))
        End If
    End Sub

    Public Sub RemoveIndex(ByVal a_property As System.ComponentModel.PropertyDescriptor) Implements System.ComponentModel.IBindingList.RemoveIndex
        If supportsBinding Then
            bindingList.RemoveIndex(a_property)
        End If
    End Sub

    Public Sub RemoveSort() Implements System.ComponentModel.IBindingList.RemoveSort
        If IsSorted Then
            UndoSort()
        End If
    End Sub

    Public ReadOnly Property AllowEdit() As Boolean Implements System.ComponentModel.IBindingList.AllowEdit
        Get
            If supportsBinding Then
                Return bindingList.AllowEdit
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property AllowNew() As Boolean Implements System.ComponentModel.IBindingList.AllowNew
        Get
            If supportsBinding Then
                Return bindingList.AllowNew
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property AllowRemove() As Boolean Implements System.ComponentModel.IBindingList.AllowRemove
        Get
            If supportsBinding Then
                Return bindingList.AllowRemove
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property BaseList() As IList
        Get
            Return Microsoft.VisualBasic.IIf((isFiltered), filteredList, _BaseList)
        End Get
    End Property

    Public ReadOnly Property Count() As Integer Implements System.Collections.ICollection.Count
        Get
            Return BaseList.Count
        End Get
    End Property

    Public ReadOnly Property IsFixedSize() As Boolean Implements System.Collections.IList.IsFixedSize
        Get
            Return BaseList.IsFixedSize
        End Get
    End Property

    Public ReadOnly Property IsReadOnly() As Boolean Implements System.ComponentModel.IBindingList.IsReadOnly
        Get
            Return True
        End Get
    End Property

    Public ReadOnly Property IsSorted() As Boolean Implements System.ComponentModel.IBindingList.IsSorted
        Get
            Return _isSorted
        End Get
    End Property

    Public ReadOnly Property IsSynchronized() As Boolean Implements System.Collections.ICollection.IsSynchronized
        Get
            Return BaseList.IsSynchronized
        End Get
    End Property

    Public ReadOnly Property SortDirection() As System.ComponentModel.ListSortDirection Implements System.ComponentModel.IBindingList.SortDirection
        Get
            Return SortDirection
        End Get
    End Property

    Public ReadOnly Property SortProperty() As System.ComponentModel.PropertyDescriptor Implements System.ComponentModel.IBindingList.SortProperty
        Get
            Return sortBy
        End Get
    End Property

    Public ReadOnly Property SupportsChangeNotification() As Boolean Implements System.ComponentModel.IBindingList.SupportsChangeNotification
        Get
            Return True
        End Get
    End Property

    Public ReadOnly Property SupportsSearching() As Boolean Implements System.ComponentModel.IBindingList.SupportsSearching
        Get
            If supportsBinding Then
                Return bindingList.SupportsSearching
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property SupportsSorting() As Boolean Implements System.ComponentModel.IBindingList.SupportsSorting
        Get
            Return True
        End Get
    End Property

    Public ReadOnly Property SyncRoot() As Object Implements System.ComponentModel.IBindingList.SyncRoot
        Get
            Return BaseList.SyncRoot
        End Get
    End Property



    Private _BaseList As IList
    Private PropertyHash As System.Collections.Hashtable = New Hashtable
    Private bindingList As IBindingList
    Private filteredList As ArrayList
    Private isFiltered As Boolean = False
    Private _isSorted As Boolean = False
    Private sortBy As PropertyDescriptor
    Private fullPropertyName As String = String.Empty
    Private _sortDirection As ListSortDirection = ListSortDirection.Ascending
    Private sortedList As ArrayList = New ArrayList
    Private supportsBinding As Boolean

    Private Sub DoSort()
        sortedList.Clear()
        If sortBy Is Nothing Then
            For Each obj As Object In BaseList
                sortedList.Add(New ListItem(obj, obj))
            Next
        Else
            Dim objectType As System.Type = Nothing
            For Each obj As Object In BaseList
                Dim sorter As Object = GetValue(obj, sortBy, fullPropertyName)
                If Not (sorter Is Nothing) AndAlso objectType Is Nothing Then
                    objectType = sorter.GetType
                Else
                    If sorter Is Nothing AndAlso Not (objectType Is Nothing) Then
                        sorter = GetNullEquivalent(objectType)
                    Else
                        If sorter Is Nothing AndAlso objectType Is Nothing Then
                            For Each obj2 As Object In BaseList
                                Dim sorter2 As Object = GetValue(obj2, sortBy, fullPropertyName)
                                If Not (sorter2 Is Nothing) Then
                                    objectType = sorter2.GetType
                                    ' break
                                End If
                            Next
                            If objectType Is Nothing Then
                                objectType = GetType(String)
                            End If
                            sorter = GetNullEquivalent(objectType)
                        End If
                    End If
                End If
                sortedList.Add(New ListItem(sorter, obj))
            Next
        End If
        sortedList.Sort()
        Me._isSorted = True
        RaiseEvent ListChanged(Me, New ListChangedEventArgs(ListChangedType.Reset, 0))
    End Sub

    Private Function GetNullEquivalent(ByVal type As Type) As Object
        If type Is GetType(Date) Then
            Return DateTime.MinValue
        End If
        If type Is GetType(System.String) Then
            Return String.Empty
        End If
        Return Nothing
    End Function

    Private Function GetPropertyDescriptor(ByVal a_property As String) As PropertyDescriptor
        Dim itemType As Type = Nothing
        If a_property.Length > 0 Then
            If PropertyHash.Count = 0 Then
                Dim props As PropertyDescriptorCollection = Nothing
                Dim t As Type = CType(BaseList, Object).GetType
                Dim defaultMembers As MemberInfo() = t.GetDefaultMembers
                For Each member As MemberInfo In defaultMembers
                    If member.MemberType = MemberTypes.Property Then
                        itemType = CType(member, PropertyInfo).GetGetMethod.ReturnType
                        GetProperties(itemType, PropertyHash)
                        ' break
                    End If
                Next
                If PropertyHash.Count = 0 Then
                    If BaseList.Count > 0 Then
                        itemType = BaseList(0).GetType
                        props = TypeDescriptor.GetProperties(itemType)
                        For Each prop As PropertyDescriptor In props
                            PropertyHash(prop.Name) = prop
                        Next
                    Else
                        Throw New Exception("Can not determine collection item type")
                    End If
                End If
            End If
            If PropertyHash.ContainsKey(a_property) Then
                Return CType(PropertyHash(a_property), PropertyDescriptor)
            End If
        End If
        Return Nothing
    End Function

    Private Sub GetProperties(ByVal itemType As Type, ByVal propertyHash As Hashtable)
        GetProperties(String.Empty, itemType, propertyHash)
    End Sub

    Private Sub GetProperties(ByVal propertyNamePrefix As String, ByVal itemType As Type, ByVal propertyHash As Hashtable)
        Dim props As PropertyDescriptorCollection = TypeDescriptor.GetProperties(itemType)
        For Each pd As PropertyDescriptor In props
            If pd.PropertyType Is itemType Then
                Throw New SystemException("Due to the crappy implemetation, nested types are not allowed")
            End If
            If IsSortableType(pd.PropertyType) Then
                Dim propertyName As String = Microsoft.VisualBasic.IIf((propertyNamePrefix.Length > 0), propertyNamePrefix + "." + pd.Name, pd.Name)
                If IsNestedType(pd.PropertyType) Then
                    GetProperties(propertyName, pd.PropertyType, propertyHash)
                Else
                    propertyHash.Add(propertyName, pd)
                End If
            End If
        Next
    End Sub

    Private Function IsSortableType(ByVal type As Type) As Boolean
        Return (Not (type.Equals(GetType(ArrayList))) AndAlso Not (type.IsSubclassOf(GetType(CollectionBase))))
    End Function

    Private Function IsNestedType(ByVal type As Type) As Boolean
        Return (Not type.IsValueType AndAlso Not (type.Equals(GetType(String))) AndAlso Not (type.Equals(GetType(Object))))
    End Function

    Private Function GetSortedItem(ByVal index As Integer) As Object
        If SortDirection = ListSortDirection.Ascending Then
            Return CType(sortedList(index), ListItem).Item
        Else
            Return CType(sortedList(sortedList.Count - 1 - index), ListItem).Item
        End If
    End Function

    Private Sub SourceChanged(ByVal sender As Object, ByVal e As ListChangedEventArgs)
        If IsSorted Then
            If e.ListChangedType = ListChangedType.ItemAdded Then
                If SortDirection = ListSortDirection.Ascending Then
                    sortedList.Add(New ListItem(sortBy.GetValue(BaseList(e.NewIndex)), BaseList(e.NewIndex)))
                Else
                    sortedList.Insert(0, New ListItem(sortBy.GetValue(BaseList(e.NewIndex)), BaseList(e.NewIndex)))
                End If
                RaiseEvent ListChanged(Me, New ListChangedEventArgs(ListChangedType.ItemAdded, sortedList.Count - 1))
            Else
                DoSort()
            End If
        Else
            RaiseEvent ListChanged(Me, e)
        End If
    End Sub

    Private Sub UndoSort()
        sortedList.Clear()
        sortBy = Nothing
        _sortDirection = ListSortDirection.Ascending
        _isSorted = False
        RaiseEvent ListChanged(Me, New ListChangedEventArgs(ListChangedType.Reset, 0))
    End Sub

    Private Class ListItem
        Implements IComparable
        Public Item As Object
        Public Key As Object

        Public Sub New(ByVal key As Object, ByVal item As Object)
            Me.Key = key
            Me.Item = item
        End Sub

        Public Function CompareTo(ByVal obj As Object) As Integer
            Dim target As Object = CType(obj, ListItem).Key
            If TypeOf Key Is IComparable Then
                Return CType(Key, IComparable).CompareTo(target)
            Else
                If Key.Equals(target) Then
                    Return 0
                Else
                    Return Key.ToString.CompareTo(target.ToString)
                End If
            End If
        End Function

        Public Overloads Overrides Function ToString() As String
            Return Key.ToString
        End Function

        Public Function CompareTo1(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo

        End Function
    End Class

    Private Class SortedEnumerator
        Implements IEnumerator

        Public Sub New(ByVal sortIndex As ArrayList, ByVal direction As ListSortDirection)
            mSortIndex = sortIndex
            mSortOrder = direction
            Reset()
        End Sub

        Public Function MoveNext() As Boolean
            If mSortOrder = ListSortDirection.Ascending Then
                If index < mSortIndex.Count - 1 Then
                    index += 1
                    Return True
                Else
                    Return False
                End If
            Else
                If index > 0 Then
                    index -= 1
                    Return True
                Else
                    Return False
                End If
            End If
        End Function

        Public Sub Reset()
            If mSortOrder = ListSortDirection.Ascending Then
                index = -1
            Else
                index = mSortIndex.Count
            End If
        End Sub

        Public ReadOnly Property Current() As Object Implements System.Collections.IEnumerator.Current
            Get
                Return CType(mSortIndex(index), ListItem).Item
            End Get
        End Property
        Private index As Integer
        Private mSortIndex As ArrayList
        Private mSortOrder As ListSortDirection


        Public Function MoveNext1() As Boolean Implements System.Collections.IEnumerator.MoveNext

        End Function

        Public Sub Reset1() Implements System.Collections.IEnumerator.Reset

        End Sub
    End Class

    Public Property Site() As ISite Implements System.ComponentModel.IComponent.Site
        Get
            Return _site
        End Get
        Set(ByVal Value As ISite)
            _site = Value
        End Set
    End Property
    Private _site As ISite = Nothing

    Public Event Disposed As System.EventHandler Implements System.ComponentModel.IComponent.Disposed

    Public Sub Dispose() Implements System.IDisposable.Dispose
        RaiseEvent Disposed(Me, EventArgs.Empty)
    End Sub

    Private Function FindChild(ByVal obj As Object, ByVal a_property As PropertyDescriptor, ByVal fullPropertyName As String) As Object
        Return FindChild(obj, a_property, fullPropertyName, String.Empty)
    End Function

    Private Function FindChild(ByVal obj As Object, ByVal a_property As PropertyDescriptor, ByVal fullPropertyName As String, ByVal recursiveName As String) As Object
        Dim pi As PropertyInfo() = obj.GetType.GetProperties
        For Each prop As PropertyInfo In pi
            Dim methodInfo As MethodInfo = prop.GetGetMethod
            If recursiveName + prop.Name = fullPropertyName AndAlso methodInfo.ReturnType Is a_property.PropertyType Then
                Return obj
            Else
                If IsSortableType(methodInfo.ReturnType) AndAlso IsNestedType(methodInfo.ReturnType) Then
                    Dim o As Object = FindChild(prop.GetGetMethod.Invoke(obj, Nothing), a_property, fullPropertyName, recursiveName + prop.Name + ".")
                    If Not (o Is Nothing) Then
                        Return o
                    End If
                End If
            End If
        Next
        Return Nothing
    End Function

    Private Function GetValue(ByVal obj As Object, ByVal a_property As PropertyDescriptor, ByVal fullPropertyName As String) As Object
        If obj.GetType Is a_property.ComponentType Then
            Return a_property.GetValue(obj)
        End If
        Dim child As Object = FindChild(obj, a_property, fullPropertyName)
        If Not (child Is Nothing) Then
            Return a_property.GetValue(child)
        End If
        Throw New Exception("Reflection Error: Couldn't Find Child Property")
    End Function


    Default Public Overloads Property Blubber(ByVal index As Integer) As Object Implements System.Collections.IList.Item
        Get
            If IsSorted Then
                Return GetSortedItem(index)
            Else
                Return BaseList(index)
            End If
        End Get
        Set(ByVal Value As Object)
            If IsSorted Then
                Dim pos As Integer = BaseList.IndexOf(GetSortedItem(index))
                BaseList(pos) = Value
                If Not supportsBinding Then
                    DoSort()
                End If
            Else
                BaseList(index) = Value
            End If
        End Set
    End Property

End Class



