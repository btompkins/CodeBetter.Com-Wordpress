using System;
using System.Web.UI;
using Tompkins.Examples;

namespace Tompkins
{
	/// <summary>
	/// Summary description for ModalPanel.
	/// </summary>
	public class ModalPanel : Page
	{
		protected Tompkins.Web.UI.WebControls.ButtonPlus ButtonPlus1;
		protected Tompkins.Web.UI.WebControls.ModalPanel ModalPanel1;
	
		private void Page_Load(object sender, EventArgs e)
		{
			// Put user code to initialize the page here
			DataBind();
		}

		public override void DataBind()
		{
			base.DataBind ();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ButtonPlus1.Click += new System.EventHandler(this.ButtonPlus1_Click);
			this.ModalPanel1.WindowClosed += new System.EventHandler(this.ModalPanel1_WindowClosed);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ModalPanel1_WindowClosed(object sender, System.EventArgs e)
		{
			this.ModalPanel1.Visible = false;
		}

		private void ButtonPlus1_Click(object sender, System.EventArgs e)
		{
			this.ModalPanel1.Visible = true;
		}
	}
}
