using System;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace Tompkins.Web.UI.WebControls
{
	/// <summary>
	/// Summary description for CalendarPlus.
	/// </summary>
	[DefaultProperty("Text"), 
	ToolboxData("<{0}:CalendarPlus runat=server></{0}:CalendarPlus>")]
	public class CalendarPlus : WebControl
	{
		private bool allowFreeText;
		private bool showTime = false;
		private FontUnit textBoxFontSize;
		private string imageURL;
		private string dateFormat = String.Empty;

		protected DropDownList ddHour;
		protected DropDownList ddMinute;

		protected Calendar cal;
		protected TextBox txtDate;
		protected System.Web.UI.WebControls.ImageButton img;
		protected Panel pnl;
		protected HtmlInputHidden hidClickX;
		protected HtmlInputHidden hidClickY;

		/// <summary>
		/// Ons the init.
		/// </summary>
		/// <param name="e">E.</param>
		protected override void OnInit(System.EventArgs e)
		{
			this.InitializeComponent();
			base.OnInit(e);
		}

		private void img_Click(object o, System.Web.UI.ImageClickEventArgs e)
		{
			if(this.hidClickX.Value.Length > 0)
			{
				this.pnl.Style.Add("TOP",  Convert.ToString(Convert.ToInt16(this.hidClickY.Value) + e.Y));
				this.pnl.Style.Add("LEFT", Convert.ToString(Convert.ToInt16(this.hidClickX.Value) + e.X));
				this.pnl.Visible = !this.pnl.Visible;
			}
		}

		/// <summary>
		/// Gets or sets the text.
		/// </summary>
		/// <value></value>
		[Bindable(true)]
		public string Text
		{
			get {return this.txtDate.Text;}
			set {this.txtDate.Text = value;}
		}

		/// <summary>
		/// Initializes the component.
		/// </summary>
		protected void InitializeComponent()
		{
			#region JavaScript
			this.Page.RegisterClientScriptBlock("POPUP_POSITIONING", 
				@"
				<script language='javascript'>
					<!--
					function SetHiddenFieldXY(object, parent, hiddenX, hiddenY)
					{
						document.all[hiddenX].value = getRealPos(document.all[object],'Left') - getParentDivPos(document.all[object],'Left');
						document.all[hiddenY].value = getRealPos(document.all[object],'Top') - getParentDivPos(document.all[object],'Top');
					}

					function getParentDivPos(el, which)
					{
						iPos = 0;
						tmpPos = 0;
						while(el!= null)
						{
							tmpPos = el['offset' + which];
	 						if(tmpPos != 0) iPos = tmpPos;
							el = el.offsetParent;
						}

						return iPos
					}

					function getRealPos(el,which) {
						iPos = 0;
						while (el!=null) {
	 						iPos += el['offset' + which];
							el = el.offsetParent;
						}
						return iPos
					}

					//-->
				</script>
				");
			#endregion

			hidClickX = new HtmlInputHidden();
			hidClickY = new HtmlInputHidden();
			this.Controls.Add(hidClickX);
			this.Controls.Add(hidClickY);
			
			txtDate = new TextBox();
			int txtBoxWidth = Convert.ToInt16(this.Width.Value) - 12;
			if(txtBoxWidth > 0)	txtDate.Width = new Unit(txtBoxWidth);
			txtDate.Font.Size = this.textBoxFontSize;
			txtDate.Enabled = this.allowFreeText;
			this.Controls.Add(txtDate);

			if(showTime)
			{
				ddHour = new DropDownList();
				for(int i = 0; i<24; i++)
				{
					ddHour.Items.Add(i.ToString());
				}

				this.Controls.Add(ddHour);
				
				ddMinute = new DropDownList();
				for(int i = 0; i<60; i++)
				{
					string timeString = i.ToString();
					if(timeString.Length == 1) timeString = "0" + timeString;
					ddMinute.Items.Add(new ListItem(timeString, i.ToString()));
				}

				this.Controls.Add(ddHour);
				this.Controls.Add(ddMinute);

			}

			img = new System.Web.UI.WebControls.ImageButton();
			img.ImageUrl = this.imageURL;
		
			//img.ID = "CALENDAR_ICON";
			//img.Attributes.CssStyle.Add("POSITION", "ABSOLUTE");
			
			if(this.Enabled)
				img.Click += new System.Web.UI.ImageClickEventHandler(this.img_Click);
	
			this.Controls.Add(img);

			img.Attributes.Add("OnMouseDown", String.Format("SetHiddenFieldXY('"+ this.img.UniqueID + "','" + this.Parent.ClientID + "', '" + this.hidClickX.UniqueID +"', '"+ this.hidClickY.UniqueID +"');"));

			pnl = new Panel();
			pnl.Width = new Unit("100px");
			pnl.Height = new Unit("100px");

			pnl.Style.Add("POSITION", "ABSOLUTE");
			pnl.Attributes.Add("NAME", "POPUP_CALENDAR");
			pnl.BackColor = Color.Red;
			pnl.Visible = false;

			cal = new Calendar();
			cal.Width			= new Unit("71px");
			cal.CellPadding		= 1;
			cal.BackColor		= Color.White;
			cal.BorderWidth		= new Unit("1px");
			cal.BorderColor		= System.Drawing.ColorTranslator.FromHtml("#3366CC");
			cal.Height			= new Unit("111px");
			cal.ForeColor		= System.Drawing.ColorTranslator.FromHtml("#003399");
			cal.Font.Names		= new string [] {"Verdana"};
			cal.Font.Size		= FontUnit.Point(8);
			
			cal.DayNameFormat	= DayNameFormat.FirstLetter;	
			cal.TodayDayStyle.ForeColor = Color.White;
			cal.TodayDayStyle.BackColor = ColorTranslator.FromHtml("#99CCCC");
				
			cal.SelectorStyle.ForeColor = ColorTranslator.FromHtml("#336666");
			cal.SelectorStyle.BackColor = ColorTranslator.FromHtml("#99CCCC");

			cal.NextPrevStyle.Font.Size = FontUnit.Point(8);
			cal.NextPrevStyle.ForeColor = ColorTranslator.FromHtml("#E7E7FF");

			cal.DayHeaderStyle.Height	= new Unit("1px");
			cal.DayHeaderStyle.ForeColor= ColorTranslator.FromHtml("#336666");
			cal.DayHeaderStyle.BackColor= ColorTranslator.FromHtml("#99CCCC");
				
			cal.SelectedDayStyle.Font.Bold	= true;
			cal.SelectedDayStyle.ForeColor	= ColorTranslator.FromHtml("#CCFF99");
			cal.SelectedDayStyle.BackColor	= ColorTranslator.FromHtml("#009999");

			cal.TitleStyle.Font.Size	= FontUnit.Point(9);
			cal.TitleStyle.Font.Bold	= true;
			cal.TitleStyle.Height		= new Unit("20px");
			cal.TitleStyle.BorderWidth	= new Unit("1px");
			cal.TitleStyle.ForeColor	= ColorTranslator.FromHtml("#E7E7FF");
			cal.TitleStyle.BorderStyle	= BorderStyle.Solid;
			cal.TitleStyle.BorderColor	= ColorTranslator.FromHtml("#3366CC");
			cal.TitleStyle.BackColor	= ColorTranslator.FromHtml("#003399");

			cal.WeekendDayStyle.BackColor		= ColorTranslator.FromHtml("#E7E7FF");			
			cal.OtherMonthDayStyle.ForeColor	= ColorTranslator.FromHtml("#999999");
			cal.SelectionChanged += new System.EventHandler(this.cal_SelectionMade);
			this.pnl.Controls.Add(cal);
			this.Controls.Add(pnl);
			

		}

		/// <summary>
		/// Gets or sets the date format.
		/// </summary>
		/// <value></value>
		public string DateFormat
		{
			get { return dateFormat; }
			set { dateFormat = value; }
		}

		private void cal_SelectionMade(object o, System.EventArgs e)
		{
			if(this.Enabled)
			{
				this.txtDate.Text = (dateFormat == null) ? cal.SelectedDate.ToShortDateString() : cal.SelectedDate.ToString(dateFormat);
			}

			this.pnl.Visible = false;
		}

		public bool AllowFreeText
		{
			get
			{
				return allowFreeText;
			}
			set
			{
				allowFreeText = value;
			}
		}


		public FontUnit TextBoxFontSize
		{
			get
			{
				return textBoxFontSize;
			}
			set
			{
				textBoxFontSize = value;
			}
		}


		public string ImageURL
		{
			get
			{
				return imageURL;
			}
			set
			{
				imageURL = value;
			}
		}

		/// <summary>
		/// Gets or sets the selected date.
		/// </summary>
		/// <value></value>
		public System.DateTime SelectedDate
		{
			get
			{
				System.DateTime selDate;

				try
				{
					selDate = Convert.ToDateTime(this.txtDate.Text);
					if(showTime)
					{
						int minute = Convert.ToInt16(ddMinute.SelectedValue);
						int hour = Convert.ToInt16(ddHour.SelectedValue);
						selDate =  new DateTime(selDate.Year, selDate.Month, selDate.Day, hour, minute, 0);
					}
				}
				catch
				{
					throw new CalendarPlusDateFormatException("Could Not Convert Date");
				}

				return selDate;
			}
			set
			{
				this.txtDate.Text = (dateFormat.Length > 0) ? value.ToString("d") : value.ToString(dateFormat) ;
				if(showTime)
				{
					this.ddHour.SelectedValue = value.Hour.ToString();
					this.ddMinute.SelectedValue = value.Minute.ToString();
				}
			}
		}

		public bool ShowTime
		{
			get { return showTime; }
			set { showTime = value; }
		}
	
		public override void RenderBeginTag(HtmlTextWriter writer)
		{
			// TODO:  Add CalendarPlus.RenderBeginTag implementation
			//base.RenderBeginTag (writer);
		}
	
		public override void RenderEndTag(HtmlTextWriter writer)
		{
			// TODO:  Add CalendarPlus.RenderEndTag implementation
			//base.RenderEndTag (writer);
		}
	}
	
	public class CalendarPlusDateFormatException : System.Exception 
	{
		public CalendarPlusDateFormatException(string msg) : base(msg) {}
	}
}
