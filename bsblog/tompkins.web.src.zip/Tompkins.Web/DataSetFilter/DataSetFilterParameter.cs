using System;

namespace Tompkins.Web.UI.WebControls.DataSetFilter
{
	/// <summary>
	/// This Class represents a parameter for a dataset filter
	/// </summary>
	[Serializable]
	public class DataSetFilterParameter
	{
		private System.Type m_typParameterType;
		private string m_strPromptString;
		private string m_parameterID;
		private string m_strReplaceFilter;

		/// <summary>
		///     TODO: Describe this constructor here
		/// </summary>
		public DataSetFilterParameter(string parameterID, string prompt, System.Type paramaterType, string replaceFilter) : base()
		{
			this.m_strPromptString = prompt;
			this.m_typParameterType = paramaterType;
			this.m_parameterID = parameterID;
			this.m_strReplaceFilter = replaceFilter;
		}

		public DataSetFilterParameter(){}

		public string PromptString
		{
			get
			{
				return m_strPromptString;
			}
			set
			{
				m_strPromptString = value;
			}
		}

		public string ReplaceFilter
		{
			get
			{
				return m_strReplaceFilter;
			}
			set
			{
				m_strReplaceFilter = value;
			}
		}

		public string ParameterID
		{
			get
			{
				return m_parameterID;
			}
			set
			{
				m_parameterID = value;
			}
		}

		public System.Type ParameterType
		{
			get
			{
				return m_typParameterType;
			}
			set
			{
				m_typParameterType = value;
			}
		}

		private string m_paramValue;

		public string ParameterValue
		{

			get 
			{
				return this.m_paramValue;
			}

			set
			{
				this.m_paramValue = value;
			}
		}
	}


	#region "'DataSetFilterParameterCollection' strongly typed collection class"


	/// <summary>
	///     A collection that stores 'DataSetFilterParameter' objects.
	/// </summary>
	[Serializable()]
	public class DataSetFilterParameterCollection : System.Collections.CollectionBase 
	{
    
		/// <summary>
		///     Initializes a new instance of 'DataSetFilterParameterCollection'.
		/// </summary>
		public DataSetFilterParameterCollection() 
		{
		}
    
		/// <summary>
		///     Initializes a new instance of 'DataSetFilterParameterCollection' based on an already existing instance.
		/// </summary>
		/// <param name='datValue'>
		///     A 'DataSetFilterParameterCollection' from which the contents is copied
		/// </param>
		public DataSetFilterParameterCollection(DataSetFilterParameterCollection datValue) 
		{
			this.AddRange(datValue);
		}
    
		/// <summary>
		///     Initializes a new instance of 'DataSetFilterParameterCollection' with an array of 'DataSetFilterParameter' objects.
		/// </summary>
		/// <param name='datValue'>
		///     An array of 'DataSetFilterParameter' objects with which to initialize the collection
		/// </param>
		public DataSetFilterParameterCollection(DataSetFilterParameter[] datValue) 
		{
			this.AddRange(datValue);
		}
    
		/// <summary>
		///     Represents the 'DataSetFilterParameter' item at the specified index position.
		/// </summary>
		/// <param name='intIndex'>
		///     The zero-based index of the entry to locate in the collection.
		/// </param>
		/// <value>
		///     The entry at the specified index of the collection.
		/// </value>
		public DataSetFilterParameter this[int intIndex] 
		{
			get 
			{
				return ((DataSetFilterParameter)(List[intIndex]));
			}
			set 
			{
				List[intIndex] = value;
			}
		}
    
		/// <summary>
		///     Adds a 'DataSetFilterParameter' item with the specified value to the 'DataSetFilterParameterCollection'
		/// </summary>
		/// <param name='datValue'>
		///     The 'DataSetFilterParameter' to add.
		/// </param>
		/// <returns>
		///     The index at which the new element was inserted.
		/// </returns>
		public int Add(DataSetFilterParameter datValue) 
		{
			return List.Add(datValue);
		}
    
		/// <summary>
		///     Copies the elements of an array at the end of this instance of 'DataSetFilterParameterCollection'.
		/// </summary>
		/// <param name='datValue'>
		///     An array of 'DataSetFilterParameter' objects to add to the collection.
		/// </param>
		public void AddRange(DataSetFilterParameter[] datValue) 
		{
			for (int intCounter = 0; (intCounter < datValue.Length); intCounter = (intCounter + 1)) 
			{
				this.Add(datValue[intCounter]);
			}
		}
    
		/// <summary>
		///     Adds the contents of another 'DataSetFilterParameterCollection' at the end of this instance.
		/// </summary>
		/// <param name='datValue'>
		///     A 'DataSetFilterParameterCollection' containing the objects to add to the collection.
		/// </param>
		public void AddRange(DataSetFilterParameterCollection datValue) 
		{
			for (int intCounter = 0; (intCounter < datValue.Count); intCounter = (intCounter + 1)) 
			{
				this.Add(datValue[intCounter]);
			}
		}
    
		/// <summary>
		///     Gets a value indicating whether the 'DataSetFilterParameterCollection' contains the specified value.
		/// </summary>
		/// <param name='datValue'>
		///     The item to locate.
		/// </param>
		/// <returns>
		///     True if the item exists in the collection; false otherwise.
		/// </returns>
		public bool Contains(DataSetFilterParameter datValue) 
		{
			return List.Contains(datValue);
		}
    
		/// <summary>
		///     Copies the 'DataSetFilterParameterCollection' values to a one-dimensional System.Array
		///     instance starting at the specified array index.
		/// </summary>
		/// <param name='datArray'>
		///     The one-dimensional System.Array that represents the copy destination.
		/// </param>
		/// <param name='intIndex'>
		///     The index in the array where copying begins.
		/// </param>
		public void CopyTo(DataSetFilterParameter[] datArray, int intIndex) 
		{
			List.CopyTo(datArray, intIndex);
		}
    
		/// <summary>
		///     Returns the index of a 'DataSetFilterParameter' object in the collection.
		/// </summary>
		/// <param name='datValue'>
		///     The 'DataSetFilterParameter' object whose index will be retrieved.
		/// </param>
		/// <returns>
		///     If found, the index of the value; otherwise, -1.
		/// </returns>
		public int IndexOf(DataSetFilterParameter datValue) 
		{
			return List.IndexOf(datValue);
		}
    
		/// <summary>
		///     Inserts an existing 'DataSetFilterParameter' into the collection at the specified index.
		/// </summary>
		/// <param name='intIndex'>
		///     The zero-based index where the new item should be inserted.
		/// </param>
		/// <param name='datValue'>
		///     The item to insert.
		/// </param>
		public void Insert(int intIndex, DataSetFilterParameter datValue) 
		{
			List.Insert(intIndex, datValue);
		}
    
		/// <summary>
		///     Returns an enumerator that can be used to iterate through
		///     the 'DataSetFilterParameterCollection'.
		/// </summary>
		public new DataSetFilterParameterEnumerator GetEnumerator() 
		{
			return new DataSetFilterParameterEnumerator(this);
		}
    
		/// <summary>
		///     Removes a specific item from the 'DataSetFilterParameterCollection'.
		/// </summary>
		/// <param name='datValue'>
		///     The item to remove from the 'DataSetFilterParameterCollection'.
		/// </param>
		public void Remove(DataSetFilterParameter datValue) 
		{
			List.Remove(datValue);
		}
    
		/// <summary>
		///     A strongly typed enumerator for 'DataSetFilterParameterCollection'
		/// </summary>
		public class DataSetFilterParameterEnumerator : object, System.Collections.IEnumerator 
		{
        
			private System.Collections.IEnumerator iEnBase;
        
			private System.Collections.IEnumerable iEnLocal;
        
			/// <summary>
			///     Enumerator constructor
			/// </summary>
			public DataSetFilterParameterEnumerator(DataSetFilterParameterCollection datMappings) 
			{
				this.iEnLocal = ((System.Collections.IEnumerable)(datMappings));
				this.iEnBase = iEnLocal.GetEnumerator();
			}
        
			/// <summary>
			///     Gets the current element from the collection (strongly typed)
			/// </summary>
			public DataSetFilterParameter Current 
			{
				get 
				{
					return ((DataSetFilterParameter)(iEnBase.Current));
				}
			}
        
			/// <summary>
			///     Gets the current element from the collection
			/// </summary>
			object System.Collections.IEnumerator.Current 
			{
				get 
				{
					return iEnBase.Current;
				}
			}
        
			/// <summary>
			///     Advances the enumerator to the next element of the collection
			/// </summary>
			public bool MoveNext() 
			{
				return iEnBase.MoveNext();
			}
        
			/// <summary>
			///     Advances the enumerator to the next element of the collection
			/// </summary>
			bool System.Collections.IEnumerator.MoveNext() 
			{
				return iEnBase.MoveNext();
			}
        
			/// <summary>
			///     Sets the enumerator to the first element in the collection
			/// </summary>
			public void Reset() 
			{
				iEnBase.Reset();
			}
        
			/// <summary>
			///     Sets the enumerator to the first element in the collection
			/// </summary>
			void System.Collections.IEnumerator.Reset() 
			{
				iEnBase.Reset();
			}
		}
	}

	#endregion //('DataSetFilterParameterCollection' strongly typed collection class)

}
