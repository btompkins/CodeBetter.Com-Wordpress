using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tompkins.Web.Util;

namespace Tompkins.Web.UI.WebControls.DataSetFilter
{

	/// <summary>
	///     The DataSetFilterParameter Class creates a UI for adding parameters
	///     to a filter.
	/// </summary>
	[ToolboxData("<{0}:DataSetFilterParameterControl runat=server></{0}:DataSetFilterParameterControl>")]
	public class DataSetFilterParameterControl : WebControl
	{

		#region Private Members
		private bool iBolCalendarPlusAllowFreeText;
		private string m_strLabelFormat = "{0}<br>";
		private DataSetFilterParameter m_param;
		#endregion

		#region Protected Members
		protected CalendarPlus cal;
		protected TextBox txtBox;
		protected Label lblParamaterName;
		protected Label labOrDateConstants;
		protected DropDownList ddlDateConstants;
		#endregion
		
		/// <summary>
		///     Add all of the child UI controls for this control
		/// </summary>
		/// 
		/// <returns>
		///     A void value...
		/// </returns>
		protected void InitializeComponent()
		{
			lblParamaterName = new Label();
			lblParamaterName.Font.CopyFrom(this.Font);
			lblParamaterName.Text = String.Format(this.m_strLabelFormat, this.m_param.PromptString);
			this.Controls.Add(lblParamaterName);

			switch(this.m_param.ParameterType.ToString())
			{
				case "System.DateTime" : 
				{
					#region Calendar

					cal = new CalendarPlus();
					cal.AllowFreeText = this.CalendarPlusAllowFreeText;
					cal.TextBoxFontSize = FontUnit.Point(8);
					cal.Width = new Unit("100px");

					cal.ImageURL = "calendaricon.gif";
					this.Controls.Add(cal);
					#endregion

					#region DateConstant Picker
					labOrDateConstants = new Label();
					labOrDateConstants.Text = " or ";
					this.Controls.Add(labOrDateConstants);
					ddlDateConstants = new DropDownList();
					ddlDateConstants.Font.Size = FontUnit.Point(8);
					ddlDateConstants.Items.Add(new ListItem("-- Select Date Constant --", "-1"));
					foreach(DateUtils.DateTimeConstant dtc in Enum.GetValues(typeof(DateUtils.DateTimeConstant)))
					{
						ddlDateConstants.Items.Add(
							new ListItem(dtc.ToString())
							);
					}
					this.Controls.Add(ddlDateConstants);	
					#endregion

					break;
				}
				default:
				{
					#region Text Box
					txtBox				= new TextBox();
					txtBox.Font.Size	= FontUnit.Point(8);
					this.txtBox.Font.CopyFrom(this.Font);
					this.Controls.Add(txtBox);
					#endregion

					break;
				}
			}
		}


		/// <summary>
		///     Override from base control
		/// </summary>
		/// <param name="e" type="System.EventArgs">
		///     <para>
		///         
		///     </para>
		/// </param>
		/// <returns>
		///     A void value...
		/// </returns>
		protected override void OnInit(EventArgs e)
		{
			this.InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///     TODO: Describe this constructor here
		/// </summary>
		public DataSetFilterParameterControl(DataSetFilterParameter parameter) : this(parameter, true)
		{
		}

		public DataSetFilterParameterControl(DataSetFilterParameter parameter, bool boolAllowFreeText) : base()
		{
			// TODO: If appropriate, add custom parameters to this constructor and
			// then add here the corresponding extra fields initialization code
			this.CalendarPlusAllowFreeText = boolAllowFreeText;
			this.m_param = parameter;
		}

		public bool CalendarPlusAllowFreeText
		{
			get 
			{
				return iBolCalendarPlusAllowFreeText;
			}
			set 
			{
				iBolCalendarPlusAllowFreeText=value;
			}
		}

		public string ParameterToReplace
		{
			get
			{
				return this.m_param.ReplaceFilter;
			}
		}

		public string ParameterValue
		{
			get 
			{
				string returnVal;

				if(m_param.ParameterType.ToString() ==  "System.DateTime")
				{
					// We're using the calendar...
					if(this.ddlDateConstants.SelectedValue == "-1")
					{
						returnVal =  cal.SelectedDate.ToShortDateString();
					}
					else
					{
						returnVal = DateUtils.GetDateTimeConstant(this.ddlDateConstants.SelectedValue).ToString();
					}
				}
				else
				{
					returnVal = txtBox.Text;
				}

				return  returnVal;
			}
		}
	}
}
