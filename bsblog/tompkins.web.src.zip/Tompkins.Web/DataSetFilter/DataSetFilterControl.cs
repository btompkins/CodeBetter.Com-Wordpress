using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tompkins.Web.UI.WebControls.CachedDropDownLists;
using Tompkins.Web.UI.WebControls.DataSetFilter;
using Tompkins.Web.Util;

namespace Tompkins.Web.UI.WebControls
{
	/// <summary>
	///     The DataSetFilter Class creates a UI for adding filters 
	///     to a dataset.
	/// </summary>
	/// <remarks>
	///     This class internally stores filters that are applied
	///     to the dataset, but does not apply them to the DataSet
	/// </remarks>
	[ToolboxData("<{0}:DataSetFilterControl runat=server></{0}:DataSetFilterControl>"),
	DefaultEvent("FilterChanged")]
	public class DataSetFilterControl : WebControl
	{
		public event EventHandler FilterChanged;
		public event EventHandler ParameterAdded;

		#region Private Members
		private bool supportsParameters;
		private bool showClearButton = true;		
		private string calanderImageUrl = "calendaricon.gif";
		#endregion

		#region Protected Members
		protected ButtonPlus btnAddFilter;
		protected ButtonPlus btnAddParameter;
		protected CalendarPlus cal;
		protected DataSetColumnDropDownList ddlColumns;
		protected DropDownList ddlOperator;
		protected DropDownList ddlOperatorString;
		protected TextBox txtBox;
		protected DropDownList ddlBoolean;
		protected DropDownList ddlDateConstants;
		protected Label labOrDateConstants;
		protected ButtonPlus btnClear;
		#endregion
		
		#region DataSource
		[
			Bindable(true),
				Category("Data"),
				DefaultValue(null),
				DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
				Description("The data source that the control is bound to")
		]
		public DataSet DataSource 
		{
			get 
			{
				return dataSource;  
			} 
			set	
			{
				dataSource = value; 
			}
		}
		protected DataSet dataSource = null;
		#endregion

		#region DataMember
		public string DataMember
		{
			get
			{
				return (_strDataMember == null) ? (this.dataSource as DataSet).Tables[0].TableName : _strDataMember;
			}
			set
			{
				_strDataMember = value;
			}
		}
		private string _strDataMember;


		#endregion

		#region DataBind
		public override void DataBind()
		{
			ddlColumns.ValueTypes = DataSetColumnDropDownList.ItemValueType.DataSetColumnName;
				ddlColumns.CacheKey		= this.UniqueID + "_COLUMNS_DDL";
				ddlColumns.DataSource	= this.dataSource;
				ddlColumns.DataMember	= this.DataMember;
				ddlColumns.PageCache	= this.Page.Cache;
				ddlColumns.DataBind();

				DataSetFilterState state = this.FilterState;
				state.ColumnTypes = new Hashtable();
				foreach(DataColumn c in this.dataSource.Tables[this.DataMember].Columns)
				{
					state.ColumnTypes.Add(c.ColumnName, c.DataType);
				}
				this.FilterState = state;
		}
		#endregion

		/// <summary>
		/// Gets or sets the calander image URL.
		/// </summary>
		/// <value></value>
		public string CalanderImageUrl
		{
			get { return calanderImageUrl; }
			set { calanderImageUrl = value; }
		}		
		/// <summary>
		/// Gets the parameters.
		/// </summary>
		/// <value></value>
		public DataSetFilterParameterCollection Parameters
		{
			get
			{
				DataSetFilterParameterCollection parameters = new DataSetFilterParameterCollection();

				if(this.HasParameters)
				{
					int i = 0;

					string [] splitFilters = this.RowFilter.Split(new char[]{'\''});
					foreach(string filter in splitFilters)
					{
						if(filter.StartsWith("?"))
						{
							string strPromptRegex = @"PROMPT=""(?<prompt>[^""]*)""";
							string strTypeRegex = @"TYPE=""(?<type>[^""]*)""";
							string strIDRegex = @"ID=""(?<id>[^""]*)""";

							Match promptMatch = Regex.Match(filter, strPromptRegex);
							Match typeMatch = Regex.Match(filter, strTypeRegex);
							Match idMatch = Regex.Match(filter, strIDRegex);

							string strPrompt = (promptMatch.Success) ? promptMatch.Groups["prompt"].Value : "Parameter " + ++i;
							string strID = (idMatch.Success) ? idMatch.Groups["id"].Value : "PARAM " + ++i;
							
							Type type = (typeMatch.Success) ? Type.GetType(typeMatch.Groups["type"].Value) : typeof(String);
							parameters.Add(new DataSetFilterParameter(strID, strPrompt, type, filter));
						}
					}
				}

				return parameters;
			}
		}

		/// <summary>
		/// Gets the row filter.
		/// </summary>
		/// <value></value>
		public string RowFilter
		{
			get
			{
				if(FilterState.CustomFilter.Length > 0) 
				{
					string returnFilter = FilterState.CustomFilter;

					// Check to see if there are any date constants in the string..
					if(returnFilter.IndexOf("'%") > -1)
					{
						returnFilter = FillDateConstants(returnFilter);	
					}

					return returnFilter;
				}

				string s = String.Empty;
				
				foreach(DataSetFilters.FiltersRow row in FilterState.CurrentFilterDataSet.Filters)
				{
					// Fix for spaces
					string strColumn = row.COLUMN;
					
					// From DataColumn.Expression Property in help, must bracket these
					char [] bracketCharsInColum = new char [] {'\n','\t','\r','~','(',')','#','\\','/','=','>','<','+','-','*','%','&','|','^','\'','"','[',']', ' '};
					
					if(strColumn.IndexOfAny(bracketCharsInColum) > -1)
					{
						strColumn = String.Format("[{0}]", strColumn);
					}

					s += (row.IsBOOL_OPERATORNull()) ? null : row.BOOL_OPERATOR;

					string strFormat		= String.Empty;
					string strOperator		= row.OPERATOR;
					string strType			= row.COLUMN_TYPE;
					string strValue			= (row.IsVALUENull()) ? String.Empty : row.VALUE;
				
					switch(strType)
					{
						case "System.Int16" :
						case "System.Int32" :
						case "System.Int64" :
						case "System.Double" :
						{
							// if the value is a filter, quote it.
							strFormat = (row.VALUE.StartsWith("?")) ? " {0} {1} '{2}' " : " {0} {1} {2} ";
							break;
						}
						case "System.DateTime" :
						{
							if(strValue.StartsWith("?"))
							{
								// Paramaters found
								strFormat = " {0} {1} '{2}' ";
								break;
							}
							else if(strValue.IndexOf("'%") > -1) 
							{
								// Date Constants  found in the string..
								strValue = FillDateConstants(strValue);	
							}


							if(strValue == String.Empty)
							{

								strFormat = " {0} {1} ";
							}
							else
							{
								// Get the date
								DateTime dtValue = Convert.ToDateTime(strValue);

								if(strOperator == "=")
								{
									strValue = dtValue.AddMinutes(-1).ToString();
									strOperator = ">";
									strFormat = " {0} {1} #{2}# AND {0} < #" + dtValue.AddDays(1).ToShortDateString() + "# ";
								}
								else if(strOperator == "<>")
								{
									strValue = dtValue.AddMinutes(-1).ToString();
									strOperator = "<";
									strFormat = " {0} {1} #{2}# OR {0} > #"  + dtValue.AddDays(1).ToShortDateString() + "# ";
								}
								else
									strFormat = " {0} {1} #{2}# ";
							}
							break;
						}
						default:
						{
							if(strValue == String.Empty)
							{
								strFormat = " {0} {1} ";
							}
							else
							{
								strFormat = " {0} {1} '{2}' ";
							}
							break;
						}
					}

					s += String.Format(strFormat, strColumn, strOperator, strValue);
				}

				return s.Equals(String.Empty) ? s : s.Trim();
			}
		}

		/// <summary>
		/// Clears the filters.
		/// </summary>
		public void ClearFilters()
		{	
			FilterState = null;
			if(this.FilterChanged != null) this.FilterChanged(this, new EventArgs());
		}

		/// <summary>
		/// Removes the filter.
		/// </summary>
		/// <param name="filterID">Filter ID.</param>
		public void RemoveFilter(int filterID)
		{
			DataSetFilterState state = FilterState;

			DataSetFilters.FiltersRow row = state.CurrentFilterDataSet.Filters.FindByFILTER_ID(filterID);
			if(row != null && !row.IsBOOL_OPERATORNull())
			{
				row.Delete();
				FilterState = state;
				if(this.FilterChanged != null) this.FilterChanged(this, new EventArgs());
			}
			else
			{
				throw new Exception("You cannot delete the first filter. Use the Clear function instead");
			}
		}

		/// <summary>
		/// Gets or sets the row filter data set.
		/// </summary>
		/// <value></value>
		public DataSetFilters RowFilterDataSet
		{
			get 
			{
				return FilterState.CurrentFilterDataSet;
			}
			set
			{
				DataSetFilterState state = FilterState;

				state.CurrentFilterDataSet = value;
				FilterState = state;
				if(this.FilterChanged != null) this.FilterChanged(this, new EventArgs());
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether [supports parameters].
		/// </summary>
		/// <value>
		/// 	<see langword="true"/> if [supports parameters]; otherwise, <see langword="false"/>.
		/// </value>
		public bool SupportsParameters
		{
			get { return supportsParameters; }
			set { supportsParameters = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether [show clear button].
		/// </summary>
		/// <value>
		/// 	<see langword="true"/> if [show clear button]; otherwise, <see langword="false"/>.
		/// </value>
		public bool ShowClearButton
		{
			get { return showClearButton; }
			set { showClearButton = value; }
		}

		/// <summary>
		/// Gets a value indicating whether this instance has parameters.
		/// </summary>
		/// <value>
		/// 	<see langword="true"/> if this instance has parameters; otherwise, <see langword="false"/>.
		/// </value>
		public bool HasParameters
		{
			get
			{
				return (this.RowFilter.IndexOf("'?") > 0 ||
					this.RowFilter.IndexOf("= ?") > 0||
					this.RowFilter.IndexOf("> ?") > 0||
					this.RowFilter.IndexOf("< ?") > 0);
			}
		}
		
		/// <summary>
		/// Gets or sets the custom filter.
		/// </summary>
		/// <value></value>
		public string CustomFilter
		{
			get 
			{
				return FilterState.CustomFilter;
			}
			set 
			{
				DataSetFilterState state = FilterState;
				state.CustomFilter = value;
				FilterState = state;
				if(this.FilterChanged != null) this.FilterChanged(this, new EventArgs());
			}
		}

		/// <summary>
		///     The current state of the control's child control visibility.
		/// </summary>
		[Serializable]
		public class DataSetFilterState
		{
			public enum CurrentControlVisibilty
			{
				ColumnDDL			= 0x01,
				OperatorDDLNumeric	= 0x02,
				OperatorDDLString	= 0x04,
				TextBox				= 0x08,
				Calendar			= 0x10,
				BooleanDDL			= 0x20
			}

			private System.Collections.Hashtable columnTypes;

			public Hashtable ColumnTypes
			{
				get { return columnTypes; }
				set { columnTypes = value; }
			}

			public CurrentControlVisibilty CurrentControls
			{
				get
				{ 
					if(this.currentFiltersDataSet.Filters.Count > 0)
						return (this.currentVis | CurrentControlVisibilty.BooleanDDL);
					else
						return this.currentVis; 
				}
				set
				{ 
					this.currentVis = value; 
				}
			}

			public DataSetFilters CurrentFilterDataSet
			{
				get
				{ 
					return this.currentFiltersDataSet;
				}
				set 
				{
					this.currentFiltersDataSet = value;
				}
			}

			private DataSetFilters currentFiltersDataSet = new DataSetFilters();

			private string customFilter = String.Empty;

			public string CustomFilter
			{
				get
				{
					return customFilter;
				}
				set
				{
					customFilter = value;
				}
			}

			private CurrentControlVisibilty currentVis = (
				CurrentControlVisibilty.ColumnDDL | 
				CurrentControlVisibilty.OperatorDDLString | 
				CurrentControlVisibilty.TextBox
				);
		}


		/// <summary>
		/// Initializes the component.
		/// </summary>
		protected void InitializeComponent()
		{

			#region Operator List
			ddlBoolean = new DropDownList();
			ddlBoolean.Items.AddRange(new ListItem [] 
			{
				new ListItem("AND", "AND"),
				new ListItem("OR", "OR"),
				new ListItem("NOT", "NOT")
			});

			ddlBoolean.Font.Size = FontUnit.Point(8);
			this.Controls.Add(ddlBoolean);
			#endregion //Operator List

			ddlColumns = new DataSetColumnDropDownList();
			ddlColumns.AutoPostBack = true;
			ddlColumns.Font.Size = FontUnit.Point(8);
			ddlColumns.SelectedIndexChanged += new EventHandler(this.ddlColumns_selectedIndexChanged);
			this.Controls.Add(ddlColumns);

			#region Operator List
			ddlOperator = new DropDownList();
			ddlOperator.Items.AddRange(new ListItem [] 
			{
				new ListItem("= (equals)", "="),
				new ListItem("> (greater than)", ">"),						
				new ListItem(">= (greater than or equal to)", ">="),						
				new ListItem("< (less than)", "<"),
				new ListItem("<= (less than or equal to)", "<="),
				new ListItem("<> (not equal to)", "<>"),
				new ListItem("NULL (blank)", " IS NULL "),						
				new ListItem("NOT NULL (not blank)", " NOT IS NULL ")
			});

			ddlOperator.Font.Size = FontUnit.Point(8);
			this.Controls.Add(ddlOperator);
			#endregion //Operator List

			#region Operator List String
			ddlOperatorString = new DropDownList();
			ddlOperatorString.Items.AddRange(new ListItem [] 
			{
				new ListItem("= (equals)", " = "),
				new ListItem("<> (not equals)", " <> "),
				new ListItem("LIKE (contains)", " LIKE "),	
				new ListItem("NOT LIKE (doesn't contain)", " NOT LIKE "),
				new ListItem("NULL (blank)", " IS NULL "),						
				new ListItem("NOT NULL (not blank)", " NOT IS NULL ")
			});

			ddlOperatorString.Font.Size = FontUnit.Point(8);
			this.Controls.Add(ddlOperatorString);
			#endregion

			#region Text Box
			txtBox				= new TextBox();
			txtBox.Font.Size	= FontUnit.Point(8);
			this.Controls.Add(txtBox);
			#endregion

			#region DateConstant Picker
			ddlDateConstants = new DropDownList();
			ddlDateConstants.Font.Size = FontUnit.Point(8);
			ddlDateConstants.Items.Add(new ListItem("-- Select Date Constant --", "-1"));
			foreach(DateUtils.DateTimeConstant dtc in Enum.GetValues(typeof(DateUtils.DateTimeConstant)))
			{
				ddlDateConstants.Items.Add(
					new ListItem(dtc.ToString())
					);
			}
			this.Controls.Add(ddlDateConstants);

			labOrDateConstants = new Label();
			labOrDateConstants.Text = " or ";
			this.Controls.Add(labOrDateConstants);

			#endregion
						
			#region Calendar
			cal = new CalendarPlus();
			cal.AllowFreeText=true;
			cal.TextBoxFontSize = FontUnit.Point(8);
			cal.Width = new Unit("100px");

			cal.ImageURL = this.calanderImageUrl;
			this.Controls.Add(cal);
			#endregion


			this.Controls.Add(new LiteralControl("<p align=right>"));

			#region Add Filter Button
			btnAddFilter = new ButtonPlus();
			btnAddFilter.Click += new EventHandler(this.btnAddFilter_Click);
			btnAddFilter.Text = "Add Filter";

			// This prompt is only used when there are custom filters.
			btnAddFilter.Prompt = "Adding this filter will reset the custom filters.  Are you sure you want to do this?";

			this.Controls.Add(btnAddFilter);
			#endregion

			this.Controls.Add(new LiteralControl("&nbsp;"));

			#region Add Parameter Button
			if(supportsParameters)
			{	
				btnAddParameter = new ButtonPlus();
				btnAddParameter.Click += new EventHandler(this.btnAddParameter_Click);
				btnAddParameter.Text = "Add Parameter";

				// This prompt is only used when there are custom filters.
				btnAddParameter.Prompt = "Adding this parameter will reset the custom filters.  Are you sure you want to do this?";

				this.Controls.Add(btnAddParameter);
			}
			#endregion

			this.Controls.Add(new LiteralControl("&nbsp;"));

			
			#region Add Clear Button
			if(showClearButton)
			{	
				btnClear = new ButtonPlus();
				btnClear.Click +=new EventHandler(btnClear_Click);
				btnClear.Text = "Clear Filters";
				this.Controls.Add(btnClear);
			}
			#endregion
			this.Controls.Add(new LiteralControl("</p>"));

			this.ddlBoolean.Font.CopyFrom(this.Font);
			this.ddlColumns.Font.CopyFrom(this.Font);
			this.ddlOperator.Font.CopyFrom(this.Font);
			this.ddlOperatorString.Font.CopyFrom(this.Font);
			this.txtBox.Font.CopyFrom(this.Font);
			this.btnAddFilter.Font.CopyFrom(this.Font);
		}

		/// <summary>
		/// Raises the <see cref="E:System.Web.UI.Control.Init"/>
		/// event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
		protected override void OnInit(EventArgs e)
		{
			this.InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Raises the <see cref="E:System.Web.UI.Control.PreRender"/>
		/// event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> object that contains the event data.</param>
		protected override void OnPreRender(EventArgs e)
		{
			this.btnAddFilter.UsePrompt =  (FilterState.CustomFilter.Length > 0) ;
			if(this.btnAddParameter != null) this.btnAddParameter.UsePrompt = this.btnAddFilter.UsePrompt;

			this.ShowCurrentControls();
			base.OnPreRender(e);
		}

		/// <summary>
		/// Shows the current controls.
		/// </summary>
		protected void ShowCurrentControls()
		{
			this.ddlBoolean.Visible			= Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.BooleanDDL);
			this.ddlColumns.Visible			= Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.ColumnDDL);
			this.ddlOperator.Visible		= Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.OperatorDDLNumeric);
			this.ddlOperatorString.Visible	= Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.OperatorDDLString);
			this.txtBox.Visible				= Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.TextBox);
			this.cal.Visible				= Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.Calendar);
			this.ddlDateConstants.Visible	= Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.Calendar);
			this.labOrDateConstants.Visible = Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.Calendar);
			this.btnAddFilter.Visible		= Convert.ToBoolean(FilterState.CurrentControls > DataSetFilterState.CurrentControlVisibilty.ColumnDDL);
		}


		/// <summary>
	
		private void AddFilter(string boolOperator, string column, string oper, string filter)
		{
			FilterState.CurrentFilterDataSet.Filters.AddFiltersRow(boolOperator,column,this.GetColumnType(column).ToString(), oper, filter);
		}
	
		/// <summary>
		/// Handles the Click event of the btnAddFilter control.
		/// </summary>
		/// <param name="o">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnAddFilter_Click(object o, EventArgs e)
		{
			try
			{
				if(ddlColumns.SelectedItem.Value != "")
				{
					Type columnType = this.GetColumnType(ddlColumns.SelectedItem.Value);
					bool hideBoolOperator = !Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.BooleanDDL);

					switch(columnType.ToString())
					{
						case "System.DateTime" : 
						{
							try
							{
								// We're adding an IS or IS NOT NULL clause
								if(ddlOperator.SelectedValue.IndexOf("NULL") > 0)
								{
									this.AddFilter(
										(hideBoolOperator) ? null : this.ddlBoolean.SelectedItem.Value,
										this.ddlColumns.SelectedItem.Text, 
										this.ddlOperator.SelectedItem.Value, 
										null);
								}
								else
								{	
									string strDate = (this.ddlDateConstants.SelectedValue != "-1") ?
										"'%" + this.ddlDateConstants.SelectedValue + "%'" : this.cal.SelectedDate.ToShortDateString();
									this.AddFilter(
										(hideBoolOperator) ? null : this.ddlBoolean.SelectedItem.Value,
										this.ddlColumns.SelectedItem.Text, 
										this.ddlOperator.SelectedItem.Value, 
										strDate);
								}
								
							}
							catch (CalendarPlusDateFormatException) {/* didn't enter a proper date*/}
						
							break;
						}
						case "System.String":
						{	
							// We're adding an IS or IS NOT NULL clause
							if(ddlOperatorString.SelectedValue.IndexOf("NULL") > 0)
							{
								this.AddFilter(
									(hideBoolOperator) ? null : this.ddlBoolean.SelectedItem.Value,
									this.ddlColumns.SelectedItem.Text, 
									this.ddlOperatorString.SelectedItem.Value, 
									null);
							}
							else
							{	
								if(this.txtBox.Text.Trim() != "")
									this.AddFilter(
										(hideBoolOperator) ? null : this.ddlBoolean.SelectedItem.Value,
										this.ddlColumns.SelectedItem.Text, 
										this.ddlOperatorString.SelectedItem.Value, 
										this.txtBox.Text);
							}	
							break;
						}
						default:
						{
							if(this.txtBox.Text.Trim() != "")
								this.AddFilter(
									(hideBoolOperator) ? null : this.ddlBoolean.SelectedItem.Value,
									this.ddlColumns.SelectedItem.Text, 
									this.ddlOperator.SelectedItem.Value, 
									this.txtBox.Text);
							break;
						}
					}
				}
			}
			finally
			{
				DataSetFilterState state = FilterState;

				state.CustomFilter = String.Empty;
				FilterState = state;
				if(this.FilterChanged != null) this.FilterChanged(this, new EventArgs());
			}
		}

		/// <summary>
		/// Handles the Click event of the btnAddParameter control.
		/// </summary>
		/// <param name="o">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnAddParameter_Click(object o, EventArgs e)
		{
			string strFormat = "? PROMPT=\"Enter {0}\" TYPE=\"{1}\"";

			try
			{
				if(ddlColumns.SelectedItem.Value != "")
				{
					Type columnType = this.GetColumnType(ddlColumns.SelectedItem.Value);
					bool hideBoolOperator = !Convert.ToBoolean(FilterState.CurrentControls & DataSetFilterState.CurrentControlVisibilty.BooleanDDL);

					string strOperator = (columnType.ToString() == "System.String") ? this.ddlOperatorString.SelectedItem.Value : 
						this.ddlOperator.SelectedItem.Value;

					string columnName = this.ddlColumns.SelectedItem.Text;
					string filter = String.Format(strFormat, columnName, columnType.ToString());
					
					if(this.RowFilterDataSet.Filters.Select("VALUE = '" + filter + "'").Length != 0)
					{
						// We already have this filter..
						int i = 1;
						do
						{
							filter = String.Format(strFormat, columnName + " " + i++, columnType.ToString());
						}
						while (this.RowFilterDataSet.Filters.Select("VALUE = '" + filter + "'").Length != 0);
					}

					this.AddFilter(
						(hideBoolOperator) ? null : this.ddlBoolean.SelectedItem.Value,
						this.ddlColumns.SelectedItem.Text, 
						strOperator, 
						filter);
				}
			}
			finally
			{
				DataSetFilterState state = FilterState;

				state.CustomFilter = String.Empty;
				FilterState = state;
				if(this.ParameterAdded != null) this.ParameterAdded(this, new EventArgs());
			}
		}

		/// <summary>
		/// Gets the type of the column.
		/// </summary>
		/// <param name="columnName">Name of the column.</param>
		/// <returns></returns>
		private Type GetColumnType(string columnName)
		{
			return FilterState.ColumnTypes[columnName] as Type;
		}

		/// <summary>
		/// Handles the selectedIndexChanged event of the ddlColumns control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void ddlColumns_selectedIndexChanged(object sender, EventArgs e)
		{
			if(ddlColumns.SelectedItem.Value != "")
			{
				Type columnType = this.GetColumnType(ddlColumns.SelectedItem.Value);
			
				DataSetFilterState state = FilterState;

				state.CurrentControls = DataSetFilterState.CurrentControlVisibilty.ColumnDDL;

				switch(columnType.ToString())
				{
					case "System.DateTime" : 
					{
						state.CurrentControls |= (
							DataSetFilterState.CurrentControlVisibilty.Calendar | 
								DataSetFilterState.CurrentControlVisibilty.OperatorDDLNumeric
							);

						break;
					}
					case "System.String":
					{
						state.CurrentControls |= (
							DataSetFilterState.CurrentControlVisibilty.TextBox | 
								DataSetFilterState.CurrentControlVisibilty.OperatorDDLString
							);
							
						break;
					}
					default:
					{
						state.CurrentControls |= (
							DataSetFilterState.CurrentControlVisibilty.TextBox | 
								DataSetFilterState.CurrentControlVisibilty.OperatorDDLNumeric
							);
						break;
					}
				}

				FilterState = state;
			}
		}

		/// <summary>
		/// Fills the date constants.
		/// </summary>
		/// <param name="returnFilter">Return filter.</param>
		/// <returns></returns>
		private string FillDateConstants(string returnFilter)
		{

			// Get all of the date constants
			string strConstantRegex = @"'(?<replace>%(?<constant>[^%]*)%)'";
			MatchCollection dateConstantMatch = Regex.Matches(returnFilter, strConstantRegex);

			// Replace the filter with the Date Constant...
			foreach(Match match in dateConstantMatch)
			{
				DateTime constantDate = DateUtils.GetDateTimeConstant(match.Groups["constant"].Value);
				returnFilter = returnFilter.Replace(match.Groups["replace"].Value, constantDate.ToString()); 
			}

			return returnFilter;
		}

		/// <summary>
		/// Gets or sets the state of the filter.
		/// </summary>
		/// <value></value>
		private DataSetFilterState FilterState
		{
			get
			{
				if(this.ViewState["FILTERSTATE"] == null)
					return new DataSetFilterState();
				return this.ViewState["FILTERSTATE"] as DataSetFilterState;
			}
			set
			{
				this.ViewState["FILTERSTATE"] = value;
			}
		}

		/// <summary>
		/// Handles the Click event of the btnClear control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnClear_Click(object sender, EventArgs e)
		{
			this.ClearFilters();
		}
	}
}
