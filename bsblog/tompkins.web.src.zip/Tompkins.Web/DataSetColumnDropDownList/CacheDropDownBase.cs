using System;
using System.ComponentModel;
using System.Web.UI.WebControls;

namespace Tompkins.Web.UI.WebControls
{
	/// <summary>
	/// Summary description for CachedListControlBase.
	/// </summary>
	public abstract class CacheDropDownBase : DropDownList
	{
		private System.Web.Caching.Cache _cacPageCache;

		public CacheDropDownBase()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		protected string CACHE_KEY = null;
		
		private bool _addSelectPrompt = true;

		protected DisplayType _displayAs = DisplayType.Normal;

		public bool IsDataBound
		{
			get
			{
				return (this.Items.Count > 1);
			}
		} 

		public enum DisplayType
		{
			Normal
		}

		[
		Bindable(true),
		Category("Appearance")
		]
		public bool AddSelectPrompt
		{
			get 
			{
				return _addSelectPrompt;
			}
			set 
			{
				_addSelectPrompt = value;
			}
		}
		
		protected abstract ListItem [] GetListItemArray();

		public CacheDropDownBase(string strKey)
		{
			this.CACHE_KEY = strKey;
		}

		private void GetItems()
		{
			if(this.Items.Count == 0)
			{
				if(CACHE_KEY != null)
				{
					ListItem [] cacheListItems;
					cacheListItems = (this.Page != null) ?
						(ListItem []) this.Page.Cache[CACHE_KEY] : (ListItem []) this._cacPageCache[CACHE_KEY];

					if(cacheListItems == null && this.Page != null)
					{
						cacheListItems = GetListItemArray();
						this.Page.Cache.Insert(CACHE_KEY, cacheListItems);
					} 
					else if(cacheListItems == null)
					{
						cacheListItems = GetListItemArray();
						this._cacPageCache.Insert(CACHE_KEY, cacheListItems);
					}
				
					this.Items.AddRange(cacheListItems);
		
					if(_addSelectPrompt)
						this.Items.Insert(0, new ListItem("-- Select --", ""));
				}
			}
		}

		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			if(this.Items.Count == 0)
			{
				this.Items.Add("DataBind this page or control to Enable Contents");
			}
			
			base.Render(writer);

		}
	
		protected override void OnDataBinding(System.EventArgs e)
		{
			GetItems();
		}

		public System.Web.Caching.Cache PageCache
		{
			get
			{
				return _cacPageCache;
			}
			set
			{
				_cacPageCache = value;
			}
		}
	}
}
