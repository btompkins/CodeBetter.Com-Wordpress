using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace Tompkins.Web.UI.WebControls.CachedDropDownLists
{
	public class DataSetColumnDropDownList : CacheDropDownBase
	{
		private ItemValueType m_iteValueTypes = ItemValueType.DataSetColumnIndex;


		public DataSetColumnDropDownList() : base(null) {}



		public string CacheKey 
		{
			set {this.CACHE_KEY = value;}
			get {return this.CACHE_KEY;}
		}

		protected override System.Web.UI.WebControls.ListItem[] GetListItemArray()
		{
		
			ListItem [] items = null;

			if(this.DataSource is DataSet && this.DataMember != null)
			{

				DataTable dt = ((DataSet)this.DataSource).Tables[this.DataMember];

				items = new ListItem[dt.Columns.Count];

				for(int i = 0; i < dt.Columns.Count; i++)
				{
					if(this.m_iteValueTypes == ItemValueType.DataSetColumnName)
						items[i] = new ListItem(dt.Columns[i].ColumnName);
					else
						items[i] = new ListItem(dt.Columns[i].ColumnName, dt.Columns[i].Ordinal.ToString());
				}
		
			}

			return items;

		}

		public enum ItemValueType
		{
			DataSetColumnIndex,
			DataSetColumnName
		}

		public ItemValueType ValueTypes
		{
			get
			{
				return m_iteValueTypes;
			}
			set
			{
				m_iteValueTypes = value;
			}
		}

	}
}
