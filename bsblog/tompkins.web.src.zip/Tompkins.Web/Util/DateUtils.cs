using System;

namespace Tompkins.Web.Util
{
	/// <summary>
	/// Summary description for DateUtils.
	/// </summary>
	public class DateUtils
	{
		/// <summary>
		///     Supported DateTime Constants
		/// </summary>
		/// <remarks>
		///     
		/// </remarks>
		public enum DateTimeConstant
		{
			Today,
			Yesterday,
			Tomorrow,
			WeekStart,
			WeekEnd,
			WorkWeekStart,
			WorkWeekEnd,
			PreviousWeekStart,
			PreviousWeekEnd,
			PreviousWorkWeekStart,
			PreviousWorkWeekEnd,
			MonthStart,
			MonthEnd
		}

		public static DateTime GetDateTimeConstant(string strDateTimeConstant)
		{
			try
			{
				DateUtils.DateTimeConstant dtConstant = (DateUtils.DateTimeConstant) Enum.Parse(typeof(DateUtils.DateTimeConstant), strDateTimeConstant);
				return GetDateTimeConstant(dtConstant);
			}
			catch
			{
				string exMessage = "Possible DateTime Constant Values Are:";
				foreach(string constantName in Enum.GetNames(typeof(DateUtils.DateTimeConstant)))
				{
					exMessage += " " + constantName;
				}

				throw new System.Exception(exMessage);
			}
		}

		/// <summary>
		///     Get a specific DateTime constant...
		/// </summary>
		/// <param name="dateTimeConstant" type="VIT.Common.Util.DateUtils.DateTimeConstant">
		///     <para>
		///         
		///     </para>
		/// </param>
		/// <returns>
		///     A System.DateTime value...
		/// </returns>
		public static DateTime GetDateTimeConstant(DateTimeConstant dateTimeConstant)
		{
			switch(dateTimeConstant)
			{
				case  DateTimeConstant.Today:
					return System.DateTime.Today;
				case  DateTimeConstant.Yesterday:
					return Yesterday;
				case  DateTimeConstant.Tomorrow:
					return Tomorrow;
				case  DateTimeConstant.WeekStart:
					return WeekStart;
				case  DateTimeConstant.WeekEnd:
					return WeekEnd;
				case  DateTimeConstant.WorkWeekStart:
					return WorkWeekStart;
				case  DateTimeConstant.WorkWeekEnd:
					return WorkWeekEnd;
				case  DateTimeConstant.PreviousWeekStart:
					return PreviousWeekStart;
				case  DateTimeConstant.PreviousWeekEnd:
                    return PreviousWeekEnd;
				case  DateTimeConstant.PreviousWorkWeekStart:
					return PreviousWorkWeekStart;
				case  DateTimeConstant.PreviousWorkWeekEnd:
					return PreviousWorkWeekEnd;
				case  DateTimeConstant.MonthStart:
					return MonthStart;
				case  DateTimeConstant.MonthEnd:
					return MonthEnd;
				default:
					return System.DateTime.MinValue; // this should never happen
			  }
		}

		public enum DateDirection
		{
			Forward,
			Backward
		}

		private static DateTime GetDay(System.DayOfWeek dayOfWeek, int numberWeeks, DateDirection direction)
		{
			return GetDay(dayOfWeek, numberWeeks, direction, false);
		}

		/// <summary>
		/// Gets the day.
		/// </summary>
		/// <param name="dayOfWeek">Day of week.</param>
		/// <param name="numberWeeks">Number weeks.</param>
		/// <param name="direction">Direction.</param>
		/// <param name="dayEnd">Day END.</param>
		/// <returns></returns>
		private static DateTime GetDay(System.DayOfWeek dayOfWeek, int numberWeeks, DateDirection direction, bool dayEnd)
		{
			DateTime checkDate = DateTime.Today;
			while(true)
			{
				// We've passed a week marker
				if(checkDate.DayOfWeek == dayOfWeek)
				{
					if(numberWeeks == 0) break;
					numberWeeks--;
				} 

				// Loop until we find the correct day
				checkDate = (direction == DateDirection.Backward) ? checkDate.AddDays(-1) : checkDate.AddDays(1);
			} 

			// If we need the end of the day, add the ticks to get us there.
			if(dayEnd)	checkDate = checkDate.AddTicks(System.TimeSpan.TicksPerDay - 1);

			return checkDate;
		}

		public static DateTime Yesterday 
		{
			get
			{
				return System.DateTime.Today.AddDays(-1);
			}
		}

		public static DateTime Tomorrow
		{
			get
			{
				return System.DateTime.Today.AddDays(1);
			}
		}

		/// <summary>
		/// Start of week is Sunday 12:00 am
		/// </summary>
		public static DateTime WeekStart 
		{
			get
			{
				return GetDay(DayOfWeek.Sunday, 0, DateDirection.Backward);
			}
		}

		/// <summary>
		/// Saturday at 11:59:59    
		/// </summary>
		public static DateTime WeekEnd
		{
			get
			{
				return GetDay(DayOfWeek.Saturday, 0, DateDirection.Forward, true);
			}
		}

		/// <summary>
		///  Last week's Sunday
		/// </summary>
		public static DateTime PreviousWeekStart 
		{
			get
			{
				return GetDay(DayOfWeek.Sunday, 1, DateDirection.Backward);
			}
		}

		/// <summary>
		///     The end of last week, Sat night at 11:59:59
		/// </summary>
		public static DateTime PreviousWeekEnd 
		{
			get
			{
				return GetDay(DayOfWeek.Saturday, 0, DateDirection.Backward, true);
			}
		}

		/// <summary>
		///  Start of week is Monday 12:00 am
		/// </summary>
		public static DateTime WorkWeekStart 
		{
			get
			{
				return GetDay(DayOfWeek.Monday, 0, DateDirection.Backward);
			}
		}

		/// <summary>
		/// This Friday at 11:59:59    
		/// </summary>
 		public static DateTime WorkWeekEnd
		{
			get
			{
				return GetDay(DayOfWeek.Friday, 0, DateDirection.Forward, true);
			}
		}

		/// <summary>
		///  Last week's Monday
		/// </summary>
   		public static DateTime PreviousWorkWeekStart 
		{
			get
			{
				return GetDay(DayOfWeek.Monday, 1, DateDirection.Backward);
			}
		}

		/// <summary>
		///     The end of last week, Friday night at 11:59:59
		/// </summary>
		public static DateTime PreviousWorkWeekEnd 
		{
			get
			{
				return GetDay(DayOfWeek.Friday, 0, DateDirection.Backward, true);
			}
		}

		public static DateTime MonthStart 
		{
			get
			{
                return new System.DateTime(System.DateTime.Today.Year, System.DateTime.Today.Month, 1);
			}
		}

		public static DateTime MonthEnd
		{
			get
			{
				System.DateTime monthEnd = new System.DateTime(System.DateTime.Today.Year, System.DateTime.Today.Month, System.DateTime.DaysInMonth(System.DateTime.Today.Year, System.DateTime.Today.Month));
				return monthEnd.AddTicks(System.TimeSpan.TicksPerDay -1);
			}
		}
	}
}
