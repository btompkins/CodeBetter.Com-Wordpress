//------------------------------------------------------------------------------
// <copyright company="Telligent Systems">
//     Copyright (c) Telligent Systems Corporation.  All rights reserved.
// </copyright> 
//------------------------------------------------------------------------------

using System;
using System.Web.UI.WebControls;
using CommunityServer.Blogs.Components;
using CommunityServer.Components;

namespace CommunityServer.Blogs.Controls
{
	/// <summary>
	/// Summary description for AggregatePostList.
	/// </summary>
	public class FeaturedArticle : WeblogBaseTemplatedWebControl
	{
		public FeaturedArticle()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private Literal title = null;
		private Literal description = null;
		private HyperLink articleTitle = null;
		private HyperLink authorLink = null;
		private HyperLink readMore = null;
		private int maxPosts = 5;
		private int groupId = -1;
		private bool showBlog = true;
		private bool showDate = true;
		private int articleId;
		private int blogId = -1;
		private string sectionTitle = String.Empty;
		private int categoryId = -1;

		/// <summary>
		/// Gets or sets the max posts.
		/// </summary>
		/// <value></value>
		public int MaxPosts
		{
			get { return maxPosts; }
			set { maxPosts = value; }
		}

		/// <summary>
		/// Gets or sets the group id.
		/// </summary>
		/// <value></value>
		public int GroupId
		{
			get { return groupId; }
			set { groupId = value; }
		}

		protected override void AttachChildControls()
		{
			authorLink = FindControl("authorLink") as HyperLink;
			readMore = FindControl("readMore") as HyperLink;
			title = FindControl("title") as Literal;
			articleTitle = FindControl("articleTitle") as HyperLink;
			description = FindControl("description") as Literal;
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			if (!Page.IsPostBack || !EnableViewState)
			{
				DataBind();
			}
		}



		/// <summary>
		/// Gets or sets a value indicating whether [show blog].
		/// </summary>
		/// <value>
		/// 	<c>true</c> if [show blog]; otherwise, <c>false</c>.
		/// </value>
		public bool ShowBlog
		{
			get { return showBlog; }
			set { showBlog = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether [show date].
		/// </summary>
		/// <value>
		/// 	<c>true</c> if [show date]; otherwise, <c>false</c>.
		/// </value>
		public bool ShowDate
		{
			get { return showDate; }
			set { showDate = value; }
		}

		/// <summary>
		/// Gets or sets the article id.
		/// </summary>
		/// <value></value>
		public int ArticleId
		{
			get { return articleId; }
			set { articleId = value; }
		}


		/// <summary>
		/// Gets or sets the title.
		/// </summary>
		/// <value></value>
		public string Title
		{
			get { return sectionTitle; }
			set { sectionTitle = value; }
		}

		public override void DataBind()
		{
			base.DataBind();

			if (sectionTitle.Length > 0)
			{
				title.Text = sectionTitle;
			}

			BlogPostQuery query = new BlogPostQuery();
			query.PostID = this.articleId;

			query.IncludeCategories = false;
			query.ReturnFullThread = true;
			//query.BlogID = CurrentWeblog.SectionID;

			PostSet ps = WeblogPosts.GetPosts(query, true);
			if (ps != null)
			{
				ps.Organize();

				WeblogPost we = ps.ThreadStarter as WeblogPost;
				this.articleTitle.Text = we.Subject;
				this.articleTitle.NavigateUrl = BlogUrls.Instance().Post(we);
				this.readMore.NavigateUrl = BlogUrls.Instance().Post(we);

				this.authorLink.ImageUrl = we.User.AvatarUrl;
				this.description.Text = we.Excerpt;
			}
		}

		/// <summary>
		/// Gets or sets the blog id.
		/// </summary>
		/// <value></value>
		public int BlogId
		{
			get { return blogId; }
			set { blogId = value; }
		}


		/// <summary>
		/// Gets or sets the category id.
		/// </summary>
		/// <value></value>
		public int CategoryId
		{
			get { return categoryId; }
			set { categoryId = value; }
		}

	}
}