//------------------------------------------------------------------------------
// <copyright company="Telligent Systems">
//     Copyright (c) Telligent Systems Corporation.  All rights reserved.
// </copyright> 
//------------------------------------------------------------------------------

using System;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using CommunityServer.Blogs.Components;
using CommunityServer.Components;
using CommunityServer.Controls;

namespace CommunityServer.Blogs.Controls
{
	/// <summary>
	/// Summary description for AggregateList.
	/// </summary>
	public class AggregateCompactList : WeblogBaseTemplatedWebControl
	{
		public AggregateCompactList()
		{
			//
			// TODO: Add constructor logic here
			//
		}


	    Repeater posts = null;


        private object _dataSource;
        /// <summary>
        /// Property DataSource (object)
        /// </summary>
        public object DataSource
        {
            get {  return this._dataSource; }
            set {  this._dataSource = value; }
        }

        public override void DataBind()
        {
            base.DataBind ();
            if(DataSource != null)
            {
                posts.DataSource = DataSource;
                posts.DataBind();
            }
        }

		private bool showComments = true;

		public bool ShowComments
		{
			get { return showComments; }
			set { showComments = value; }
		}

		private bool showBlog = true;
		private bool showExcerpt = true;
		private bool showDate = true;

		public bool ShowExcerpt
		{
			get { return showExcerpt; }
			set { showExcerpt = value; }
		}

		public bool ShowBlog
		{
			get { return showBlog; }
			set { showBlog = value; }
		}

		public bool ShowDate
		{
			get { return showDate; }
			set { showDate = value; }
		}

	    protected override void AttachChildControls()
	    {
            posts = FindControl("Posts") as Repeater;
            posts.ItemDataBound +=new RepeaterItemEventHandler(posts_ItemDataBound);
        }

        private void posts_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                WeblogPost post = e.Item.DataItem as WeblogPost;
                if(post != null)
                {
                    HyperLink titleLink = e.Item.FindControl("TitleLink") as HyperLink;
                    titleLink.Text = post.Subject;
                    titleLink.NavigateUrl = BlogUrls.Instance().Post(post);

					if(showBlog)
					{						
						HyperLink Blog = e.Item.FindControl("Blog") as HyperLink;
						Blog.NavigateUrl = BlogUrls.Instance().HomePage(post.Section.ApplicationKey);
						Blog.Text = post.Section.Name;
					}

					if(showDate)
					{
						Literal Posted = e.Item.FindControl("Posted") as Literal;
						Posted.Text = post.BloggerTime.ToShortDateString() + " " + post.BloggerTime.ToShortTimeString();
					}

					if(showExcerpt && post.Excerpt != null)
					{
						Literal Excerpt = e.Item.FindControl("Excerpt") as Literal;
						Excerpt.Text = post.Excerpt;;
					}

					HyperLink link = e.Item.FindControl( "CommentsLink" ) as HyperLink;
					if(link != null) 
					{
						if(showComments && post.Weblog.EnableComments && !post.IsLocked)
						{
							link.Text = string.Format(ResourceManager.GetString("Weblog_EntryList_Comments"),post.Replies);
							link.NavigateUrl = BlogUrls.Instance().Post(post,post.Weblog) + "#comments";
							e.Item.FindControl("CommentDesc").Visible = true;
						}
						else
						{
							e.Item.FindControl("CommentDesc").Visible = false;
							link.Visible = false;
						}
					}
				
					RatingImageButton Ratings = e.Item.FindControl("Ratings") as RatingImageButton;

					if(post.EnableRatings)
					{
						Ratings.Visible = true;

						Ratings.TotalRatings = post.TotalRatings;
						Ratings.Rating = post.Rating;
					}
					else
					{
						Ratings.Visible = false;
					}

					HyperLink linkImage = e.Item.FindControl("linkImage") as HyperLink;
					if(linkImage != null)
					{
						linkImage.NavigateUrl = titleLink.NavigateUrl;
						linkImage.ToolTip = post.Subject;
					}
                }
            }
        }

	}
}
