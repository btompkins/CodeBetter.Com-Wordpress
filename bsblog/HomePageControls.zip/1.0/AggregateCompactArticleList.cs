//------------------------------------------------------------------------------
// <copyright company="Telligent Systems">
//     Copyright (c) Telligent Systems Corporation.  All rights reserved.
// </copyright> 
//------------------------------------------------------------------------------

using System;
using System.Web.UI.WebControls;
using CommunityServer.Blogs.Components;
using CommunityServer.Components;

namespace CommunityServer.Blogs.Controls
{
	/// <summary>
	/// Summary description for AggregatePostList.
	/// </summary>
	public class AggregateCompactArticleList : WeblogBaseTemplatedWebControl
	{
		public AggregateCompactArticleList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	    AggregateCompactList posts = null;
		Literal title = null;
		Literal description = null;

		public int MaxPosts
		{
			get { return maxPosts; }
			set { maxPosts = value; }
		}

		int maxPosts = 5;
		int groupId = -1;

		public int GroupId
		{
			get { return groupId; }
			set { groupId = value; }
		}

		protected override void AttachChildControls()
	    {
	        posts = FindControl("Posts") as AggregateCompactList;
            title = FindControl("title") as Literal;
			description = FindControl("description") as Literal;

        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if ( !Page.IsPostBack || !EnableViewState ) 
            {
                DataBind();
            }
        }

		private bool showBlog = true;
		private bool showDate = true;

		public bool ShowBlog
		{
			get { return showBlog; }
			set { showBlog = value; }
		}

		private bool showComments = false;

		public bool ShowComments
		{
			get { return showComments; }
			set { showComments = value; }
		}

		public bool ShowDate
		{
			get { return showDate; }
			set { showDate = value; }
		}

        public override void DataBind()
        {
            base.DataBind ();

			PostCategory pc = PostCategories.GetCategory(CategoryId,CategoryType. BlogArticle, BlogId,false);
			if(pc != null)
			{
				if(title != null)
					title.Text = pc.Name;

				if(description != null)
					description.Text = pc.Description;

			}

			BlogThreadQuery query = new BlogThreadQuery();
			query.BlogID = blogId;
			query.CategoryID = categoryId;
			query.BlogPostType = BlogPostType.Article;
			query.BlogThreadType = BlogThreadType.Category;
			query.IsPublished = true;
			//query.SortOrder = SortOrder;

			ThreadSet ts = WeblogPosts.GetBlogThreads(query,true);

			posts.ShowBlog = this.showBlog;
			posts.ShowDate = this.showDate;
			posts.ShowExcerpt = this.showExcerpt;
			posts.ShowComments = this.showComments;

			posts.DataSource = ts.Threads;
            posts.DataBind();
        }

		private bool showExcerpt = true;
		public bool ShowExcerpt
		{
			get { return showExcerpt; }
			set { showExcerpt = value; }
		}
		public int BlogId
		{
			get { return blogId; }
			set { blogId = value; }
		}

		private int blogId = -1;
		
		public int CategoryId
		{
			get { return categoryId; }
			set { categoryId = value; }
		}

		private int categoryId = -1;
	}
}
