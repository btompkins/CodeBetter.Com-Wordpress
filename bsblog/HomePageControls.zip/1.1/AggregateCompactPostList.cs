//------------------------------------------------------------------------------
// <copyright company="Telligent Systems">
//     Copyright (c) Telligent Systems Corporation.  All rights reserved.
// </copyright> 
//------------------------------------------------------------------------------

using System;
using System.Web.UI.WebControls;
using CommunityServer.Blogs.Components;
using CommunityServer.Components;

namespace CommunityServer.Blogs.Controls
{
	/// <summary>
	/// Summary description for AggregatePostList.
	/// </summary>
	public class AggregateCompactPostList : WeblogBaseTemplatedWebControl
	{
		public AggregateCompactPostList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	    AggregateCompactList posts = null;
		HyperLink title = null;
		string sectionTitle = String.Empty;
		HyperLink hl = null;				

		public BlogPostType PostType
		{
			get { return postType; }
			set { postType = value; }
		}

		BlogPostType postType = BlogPostType.Post;

		public string Title
		{
			get { return sectionTitle; }
			set { sectionTitle = value; }
		}

		private string titleLink = String.Empty;
		private string titleRssLink = String.Empty;

		public string TitleLink
		{
			get { return titleLink; }
			set { titleLink = value; }
		}

		public string TitleRssLink
		{
			get { return titleRssLink; }
			set { titleRssLink = value; }
		}

		public int MaxPosts
		{
			get { return maxPosts; }
			set { maxPosts = value; }
		}

		int maxPosts = 5;
		int groupId = -1;

		public int GroupId
		{
			get { return groupId; }
			set { groupId = value; }
		}

		protected override void AttachChildControls()
	    {
	        posts = FindControl("Posts") as AggregateCompactList;
			title = FindControl("title") as HyperLink;
			hl = FindControl("rssLink") as HyperLink;				
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if ( !Page.IsPostBack || !EnableViewState ) 
            {
                DataBind();
            }
        }


		BlogThreadSortBy sortBy = BlogThreadSortBy.MostRecent;

		public BlogThreadSortBy SortBy
		{
			get { return sortBy; }
			set { sortBy = value; }
		}

		private bool showExcerpt = true;
		public bool ShowExcerpt
		{
			get { return showExcerpt; }
			set { showExcerpt = value; }
		}

		private bool showBlog = true;
		private bool showDate = true;

		private bool showComments = true;

		public bool ShowComments
		{
			get { return showComments; }
			set { showComments = value; }
		}


		public bool ShowBlog
		{
			get { return showBlog; }
			set { showBlog = value; }
		}

		public bool ShowDate
		{
			get { return showDate; }
			set { showDate = value; }
		}

		public override void DataBind()
        {
            base.DataBind ();
        	BlogThreadQuery query = new BlogThreadQuery();
	

			if(sectionTitle.Length > 0)
			{
				title.Text = sectionTitle;
			}
			else if(GroupId > -1)
            {
                title.Text = string.Format( ResourceManager.GetString("LatestPostsTo"), WeblogGroups.GetWeblogGroup(GroupId,true,false).Name);
            }
            else
            {
                title.Text = ResourceManager.GetString("LatestPosts");
            }

			if(titleRssLink.Length > 0)
			{
				hl.NavigateUrl = titleRssLink;
			}
			else
			{
				hl.Visible = false;
			}

			if(titleLink.Length > 0)
			{
				title.NavigateUrl = titleLink;
			}


            query.BlogGroupID = GroupId;
            query.BlogPostType = this.postType;
            query.BlogThreadType = BlogThreadType.Recent;
            query.IncludeCategories = false;
            query.IsPublished = true;
            query.PageSize = 25;
            query.SortBy = sortBy;
            query.SortOrder = SortOrder.Descending;
            query.PostConfig = BlogPostConfig.IsCommunityAggregated;
			query.FilterByList = Sections.FilterByAccessControl(Weblogs.GetWeblogs(false,true,false),Permission.View);
			query.DateFilter = DateTime.Today;

            ThreadSet ts = WeblogPosts.GetBlogThreads(query,true,true);
			if(ts.Threads != null && ts.Threads.Count > this.maxPosts)
			{
				ts.Threads = ts.Threads.GetRange(0, this.maxPosts);
			}

			posts.ShowBlog = this.showBlog;
			posts.ShowDate = this.showDate;
			posts.ShowExcerpt = this.showExcerpt;
			posts.ShowComments = this.showComments;
            posts.DataSource = ts.Threads;
            posts.DataBind();
        }
    }
}