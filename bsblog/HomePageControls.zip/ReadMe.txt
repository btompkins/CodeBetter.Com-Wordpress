Control 1:   FeaturedArticle
Purpose: This control shows one featured article, along with the excerpt and the author�s avatar.
Files Needed : FeaturedArticle.cs, Skin-FeaturedArticle.ascx

Control 2:   AggregateCompactPostList
Purpose: Shows a configurable number of latest and most popular posts.
Files Needed : AggregateCompactPostList.cs, Skin-AggregateCompactPostList.ascx, AggregatePostList.cs, AggregatePostList.ascx

Control 3:   AggregateCompactArticleList
Purpose: Displays an article�s category title, excerpt, and published articles.
Files Needed : AggregateCompactArticleList.cs, Skin-AggregateCompactArticleList.ascx, AggregatePostList.cs, AggregatePostList.ascx

You�ll also need some css styles added to CommunityServer�s style sheet (via default.aspx in the Themes/default/style directory)

All CS files go in the CommunityServerBlogs project in the Controls/AggregateBlogControls directory, and all ascx files go in the CommunityServerWeb project in the Themes/Default/Skins/Blogs directory.