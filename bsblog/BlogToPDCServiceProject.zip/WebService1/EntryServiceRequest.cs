using System;

namespace BMWTPDC
{
	[Serializable]
	public class EntryServiceRequest
	{
		string firstName = String.Empty;
		string lastName  = String.Empty;
		string blogUrl  = String.Empty;
		string interests = String.Empty;

		public string FirstName
		{
			get { return firstName; }
			set { firstName = value; }
		}

		public string LastName
		{
			get { return lastName; }
			set { lastName = value; }
		}

		public string BlogUrl
		{
			get { return blogUrl; }
			set { blogUrl = value; }
		}

		public string Interests
		{
			get { return interests; }
			set { interests = value; }
		}
	}

}
