using System;
using System.Collections;
using System.ComponentModel;

namespace BMWTPDC
{
	[ToolboxItem(true)]
	[DesignTimeVisible (true)]
	[Serializable()]
	public class EntryServiceRequestCollection : CollectionBase, IComponent, IDisposable
	{
    
		#region IComponent Members
		// Added to implement Site property correctly.
		private ISite _site = null;
    
		/// <summary>
		/// Get/Set the site where this data is
		/// located.
		/// </summary>
		public ISite Site
		{
			get { return _site;  }
			set { _site = value; }
		}
		#endregion   
 
		#region IDisposable Members
		/// <summary>
		/// Notify those that care when we dispose.
		/// </summary>
		public event System.EventHandler Disposed;
    
		/// <summary>
		/// Clean up. Nothing here though.
		/// </summary>
		public void Dispose()
		{
			// Nothing to clean.
			if (Disposed != null)
				Disposed (this, EventArgs.Empty);
		}
		#endregion
    
		#region Add
		public int Add(EntryServiceRequest aEntryServiceRequest)
		{
			return List.Add(aEntryServiceRequest);
		}
		#endregion

		#region IndexOf
		public int IndexOf(EntryServiceRequest aEntryServiceRequest)
		{
			for(int i = 0; i < List.Count; i++)
				if (this[i] == aEntryServiceRequest)    // Found it
					return i;
			return -1;
		}
		#endregion
    	
		#region Insert
		public void Insert(int index, EntryServiceRequest aEntryServiceRequest)
		{
			List.Insert(index, aEntryServiceRequest);
		}
		#endregion

		#region Remove
		public void Remove(EntryServiceRequest aEntryServiceRequest)
		{
			List.Remove(aEntryServiceRequest);
		}
		#endregion

		#region Find
		// TODO: If desired, change parameters to Find method to search based on a property of EntryServiceRequest.
		public EntryServiceRequest Find(string blogUrl)
		{
			foreach(EntryServiceRequest lEntryServiceRequest in this)
				if (lEntryServiceRequest.BlogUrl == blogUrl)    // Found it
					return lEntryServiceRequest;
			return null;    // Not found
		}
		#endregion

		#region Contains
		// TODO: If you changed the parameters to Find (above), change them here as well.
		public bool Contains(EntryServiceRequest aEntryServiceRequest)
		{
			return (Find(aEntryServiceRequest.BlogUrl) != null);
		}
		#endregion
    	
		#region this[int aIndex]
		public EntryServiceRequest this[int index] 
		{
			get
			{
				return (EntryServiceRequest) List[index];
			}
			set
			{
				List[index] = value;
			}
		}
		#endregion
	}
}
