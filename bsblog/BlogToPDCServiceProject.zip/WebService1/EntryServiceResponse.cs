using System;

namespace BMWTPDC
{
	[Serializable]
	public class EntryServiceResponse
	{
		string postBody = String.Empty;

		public string PostBody
		{
			get { return postBody; }
			set { postBody = value; }
		}

	}

}
