using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using System.Xml;

/// <summary>
///     Class with utilities for the serialization of objects to and from XML
/// </summary>
/// <remarks>
///     
/// </remarks>
public class SerializationHelper
{
	/// <summary>
	/// Serialize an object using the Binary Formatter
	/// </summary>
	/// <param name="serializableObject">Object that can be serialized</param>
	/// <returns>byte[] representation of the object</returns>
	public byte[] BinarySerialize(object serializableObject)
	{
		BinaryFormatter bf = new BinaryFormatter();
		MemoryStream ms = new MemoryStream();

		bf.Serialize(ms,serializableObject);

		return ms.ToArray();
	}

	/// <summary>
	/// Restore (Deserialize) an object, given a binary formatted byte array
	/// </summary>
	/// <param name="binaryFormattedObject">A byte[] that represents a previously binary-formatted object</param>
	/// <returns>A un-typed restored object</returns>
	public object BinaryDeSerialize(byte[] binaryFormattedObject)
	{
		BinaryFormatter bf = new BinaryFormatter();
		MemoryStream ms = new MemoryStream(binaryFormattedObject);

		return bf.Deserialize(ms);
	}

	/// <summary>
	/// Serialize an object into XML
	/// </summary>
	/// <param name="serializableObject">Object that can be serialized</param>
	/// <returns>Serial XML representation</returns>
	public static XmlNode XmlSerialize(object serializableObject)
	{
		XmlSerializer serializer = new XmlSerializer(serializableObject.GetType());
		System.IO.MemoryStream aMemStr = new System.IO.MemoryStream();
		System.Xml.XmlTextWriter writer = new System.Xml.XmlTextWriter(aMemStr, null);
		serializer.Serialize(writer,serializableObject);

		string strXml = System.Text.Encoding.UTF8.GetString(aMemStr.ToArray());
		writer.Close();

		System.Console.Out.WriteLine(strXml);

		System.Xml.XmlTextReader xmlReader = new System.Xml.XmlTextReader(strXml, System.Xml.XmlNodeType.Document, null);

		xmlReader.MoveToContent();
		System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
		System.Xml.XmlNode node = doc.ReadNode(xmlReader);
		
		
		return node;
	}

	/// <summary>
	/// Restore (Deserialize) an object, given an XML string
	/// </summary>
	/// <param name="xmlString">XML</param>
	/// <param name="serializableObject">Object to restore as</param>
	public static object XmlDeSerialize(string xmlString, object serializableObject)
	{
		XmlSerializer serializer = new XmlSerializer(serializableObject.GetType());			
		System.IO.MemoryStream aStream = new
			System.IO.MemoryStream(System.Text.ASCIIEncoding.ASCII.GetBytes(xmlString));
		
		return serializer.Deserialize(aStream);
	}

	/// <summary>
	/// Restore (Deserialize) an object, given an XML string
	/// </summary>
	/// <param name="xmlString">XML</param>
	/// <param name="serializableObject">Type of object to restore as</param>
	public static object XmlDeSerialize(string xmlString, Type objectType)
	{
		XmlSerializer serializer = new XmlSerializer(objectType);			
		System.IO.MemoryStream aStream = new
			System.IO.MemoryStream(System.Text.ASCIIEncoding.ASCII.GetBytes(xmlString));
		
		return serializer.Deserialize(aStream);
	}
}