using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.UI;
using MarkItUp.WebControls;

namespace WebSmartTag
{
	public class IsbnWebSmartTag : Stream 
	{
  
		Stream responseStream;
		long position; 
		StringBuilder html = new StringBuilder();
		MarkItUp.WebControls.ContextMenuLink contextMenuLink;

		// This pattern validates ISBN numbers.  
		const string SMART_TAG_REGEX = @"\d{9}[\d|X]";

		public IsbnWebSmartTag(Stream inputStream, ContextMenuLink link) 
		{
			responseStream = inputStream;
			contextMenuLink = link;
		}
  
		#region implemented abstract members 
  
		public override bool CanRead 
		{
			get { return true; }
		}

		public override bool CanSeek 
		{
			get { return true; }
		}

		public override bool CanWrite 
		{
			get { return true; }
		}

		public override void Close() 
		{
			responseStream.Close();
		}

		public override void Flush() 
		{
			responseStream.Flush();
		}
  
		public override long Length 
		{
			get { return 0; }
		}

		public override long Position 
		{
			get { return position; }
			set { position = value; }
		}

		public override long Seek(long offset, SeekOrigin direction) 
		{
			return responseStream.Seek(offset, direction);
		}

		public override void SetLength(long length) 
		{
			responseStream.SetLength(length);
		}

		public override int Read(byte[] buffer, int offset, int count) 
		{
			return responseStream.Read(buffer, offset, count);
		}
  
		#endregion

		private string ReplaceMatchEval(System.Text.RegularExpressions.Match m) 
		{ 	

			// Set the link's text
			contextMenuLink.Text = m.Value;
			contextMenuLink.CommandArgument = m.Value;

			// Render it to a string
			StringWriter w = new StringWriter();
			HtmlTextWriter htmlWriter = new HtmlTextWriter(w);
			contextMenuLink.RenderControl(htmlWriter);

			// Return the string
			return w.ToString();
		} 
		
		public override void Write(byte[] buffer, int offset, int count) 
		{

			// string version of the buffer
			string sBuffer = UTF8Encoding.UTF8.GetString(buffer, offset, count);

			// end of the HTML file
			Regex oEndFile = new Regex("</html>", RegexOptions.IgnoreCase);
			if (oEndFile.IsMatch(sBuffer)) 
			{
				// Append the last buffer of data
				html.Append(sBuffer);
				
				// Perform the replace
				string newBuffer = Regex.Replace(html.ToString(), SMART_TAG_REGEX, new MatchEvaluator(this.ReplaceMatchEval), RegexOptions.Compiled);
				
				// Grab the bytes
				byte[] data = UTF8Encoding.UTF8.GetBytes(newBuffer);    

				// Write to the stream
				responseStream.Write(data, 0, data.Length);   
			}
			else 
			{
				html.Append(sBuffer);
			}    
		}   
	}
}
