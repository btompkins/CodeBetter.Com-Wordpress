using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using MarkItUp.WebControls;

namespace WebSmartTag
{
	/// <summary>
	///     This is the base class for all .ASPX pages in the VIT .NET Framework.
	/// </summary>
	public class PageBase : Page
	{
		protected MarkItUp.WebControls.ContextMenu menu;
		protected HtmlForm Form1;

		/// <summary>
		/// Overridden to add smart tag
		/// </summary>
		/// <param name="e"></param>
		protected override void OnInit(EventArgs e)
		{
			// Add the context menu
			menu = new ContextMenu();
			menu.ID = "WebSmartTagMenu";

			MarkItUp.WebControls.ContextMenuItem item = new ContextMenuItem();
			item.CommandArgument = "amazon";
			item.Text = "Locate on Amazon";
			menu.Items.Add(item);

			item = new ContextMenuItem();
			item.CommandArgument = "bn";
			item.Text = "Locate on Barnes & Noble";
			menu.Items.Add(item);

			menu.ItemClick +=new ContextItemClickEventHandler(menu_ItemClick);
			this.FormTag.Controls.Add(menu);

			// Create the context link
			MarkItUp.WebControls.ContextMenuLink link =	new ContextMenuLink();
			link.ContextMenuToOpen = "WebSmartTagMenu";
			link.Page = this;
			link.CssClass = "WebSmartTag";

			this.Response.Filter = new IsbnWebSmartTag(this.Response.Filter, link); 

			base.OnInit(e);
		}

		/// <summary>
		///     The current FORM tag.  Must be Form1 on the aspx page.
		/// </summary>
		public HtmlForm FormTag
		{
			get
			{
				if(Form1 == null) throw new System.Exception("Form must be named Form1!");
				return Form1;
			}
		}


		private void menu_ItemClick(object sender, ItemClickEventArgs e)
		{
			string isbn = e.LinkCommandArgument;		

			switch(e.MenuItemCommandArgument)
			{
				case "amazon" :
				{
					string url = String.Format("http://www.amazon.com/exec/obidos/tg/detail/-/{0}/ref=pd_ys_1/102-1283669-9432921?v=glance&s=books", isbn);
					Response.Redirect(url, true);
					break;
				}
				case "bn":
				{
					string url = String.Format("http://btobsearch.barnesandnoble.com/booksearch/isbninquiry.asp?ISBN={0}", isbn);
					Response.Redirect(url, true);
					break;
				}
			}
		}
	}
}
