<?php
    
    //Source of plugin
    header("Location: https://shareaholic.com"); 

?>