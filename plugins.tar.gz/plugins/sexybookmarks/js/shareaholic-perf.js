var _gaq = _gaq || [];
_gaq.push(["_setAccount", "UA-12964573-7"]);
_gaq.push(["_trackPageview"]);
(function() {
  var a = document.createElement("script");
  a.type = "text/javascript";
  a.async = !0;
  a.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
  var b = document.getElementsByTagName("script")[0];
  b.parentNode.insertBefore(a, b)
})();
