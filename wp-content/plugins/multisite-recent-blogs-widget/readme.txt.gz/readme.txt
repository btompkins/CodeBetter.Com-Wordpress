=== Multisite Recent Posts Widget ===
Contributors: copperblade
Donate link: http://bitfreedom.com/
Tags: recent posts, widget, wpmu
Requires at least: 3.0
Tested up to: 3.0.1
Stable tag: 1.1

Creates a widget to show a list of the most recent posts across a WordPress MU installation.  It shows the most recent post from each blog.  This plugin is based on the work of many authors.

== Description ==

Creates a widget to show a list of the most recent posts across a WordPress MU installation.  It shows the most recent post from each blog.  This plugin is based on the work of many authors.

This works on previous versions of WPMU, but not on previous versions of WordPress (where it doesn't make sense).


== Installation ==

1. Upload `wpmu-recent-posts-widget.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the WPMU Recent Posts widget under 'Appearance->Widgets'

== Frequently Asked Questions ==

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. Widget options

== Changelog ==

= 1.1 =
* Bugfix on base prefix

= 1.0 =
* Added widget options
* No. of days set to <= 0 will not limit by time

= 0.4 =
* Widgetized
* Set default parameters
* Removed default new posts of new blogs from results
* Thanks to:  http://lonewolf-online.net/computers/wordpress/create-widgets/

= 0.3.2 =
* Author: G. Morehouse
* Author URI: http://wiki.evernex.com/index.php?title=Wordpress_MU_sitewide_recent_posts_plugin

= 0.3.1 =
* Author: Sven Laqua
* Author URI: http://www.sl-works.de/

= 0.3 =
* Author: Ron Rennick
* Author URI: http://atypicalhomeschool.net/


== Options ==
* Number of posts to show - list this many posts.
* Number of days to limit - only go back this number of days to get posts.  Set to -1 for no limit (default).
